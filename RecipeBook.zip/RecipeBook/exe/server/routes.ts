import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage.js";
import { aiService } from "./services/ai.js";
import { terminalService } from "./services/terminal.js";
import { osintService } from "./services/osint.js";

const upload = multer({ 
  dest: path.join(process.cwd(), 'uploads'),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // AI Chat endpoint
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { provider, messages, model } = req.body;
      
      if (!provider || !messages) {
        return res.status(400).json({ error: "Provider and messages are required" });
      }

      const response = await aiService.chat(provider, messages, model);
      res.json({ response, provider, model });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get available AI providers
  app.get("/api/ai/providers", (req, res) => {
    const providers = aiService.getAvailableProviders();
    res.json(providers);
  });

  // OSINT Analysis endpoints
  app.post("/api/osint/analyze", async (req, res) => {
    try {
      const { target, type } = req.body;
      
      if (!target || !type) {
        return res.status(400).json({ error: "Target and type are required" });
      }

      let result;
      switch (type) {
        case 'phone':
          result = await osintService.analyzePhone(target);
          break;
        case 'domain':
          result = await osintService.analyzeDomain(target);
          break;
        case 'social':
          result = await osintService.analyzeSocialMedia(target);
          break;
        case 'email':
          result = await osintService.analyzeEmail(target);
          break;
        default:
          return res.status(400).json({ error: "Invalid analysis type" });
      }

      // Save result to storage
      await storage.createAnalysisResult({
        type: result.type,
        target: result.target,
        results: result.results,
        status: result.status === 'success' ? 'completed' : 'failed'
      });

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get analysis history
  app.get("/api/osint/history", async (req, res) => {
    try {
      const results = await storage.getAnalysisResults();
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Custom tool upload
  app.post("/api/tools/upload", upload.single('tool'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const { name, description } = req.body;
      const toolsDir = path.join(process.cwd(), 'tools');
      
      // Ensure tools directory exists
      if (!fs.existsSync(toolsDir)) {
        fs.mkdirSync(toolsDir, { recursive: true });
      }

      // Move file to tools directory
      const finalPath = path.join(toolsDir, req.file.originalname);
      fs.renameSync(req.file.path, finalPath);

      // Save to storage
      const tool = await storage.createCustomTool({
        name: name || req.file.originalname,
        filename: req.file.originalname,
        description: description || "",
        filePath: finalPath
      });

      res.json(tool);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get custom tools
  app.get("/api/tools", async (req, res) => {
    try {
      const tools = await storage.getCustomTools();
      res.json(tools);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Execute custom tool
  app.post("/api/tools/execute", async (req, res) => {
    try {
      const { toolId, args } = req.body;
      const tool = await storage.getCustomTool(toolId);
      
      if (!tool) {
        return res.status(404).json({ error: "Tool not found" });
      }

      // Execute the tool using terminal service
      const output = await terminalService.executeOSINTTool(tool.filename, args || "");
      res.json({ output, tool: tool.name });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);

  // WebSocket for terminal
  const wss = new WebSocketServer({ server: httpServer });

  wss.on('connection', (ws, req) => {
    const sessionId = `session-${Date.now()}-${Math.random()}`;
    const session = terminalService.createSession(sessionId);

    // Send terminal output to client
    session.emitter.on('output', (data) => {
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({ type: 'output', data }));
      }
    });

    // Handle incoming commands
    ws.on('message', (message) => {
      try {
        const { type, data } = JSON.parse(message.toString());
        
        if (type === 'command') {
          terminalService.executeCommand(sessionId, data);
        }
      } catch (error) {
        ws.send(JSON.stringify({ type: 'error', data: 'Invalid message format' }));
      }
    });

    // Cleanup on disconnect
    ws.on('close', () => {
      terminalService.destroySession(sessionId);
    });

    // Send welcome message
    ws.send(JSON.stringify({ 
      type: 'output', 
      data: 'Connected to OSINT terminal. Type "help" for available commands.\n' 
    }));
  });

  // Telegram Bots endpoints
  app.get("/api/telegram-bots", async (req, res) => {
    try {
      const bots = await storage.getTelegramBots();
      res.json(bots);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/telegram-bots", async (req, res) => {
    try {
      const bot = await storage.createTelegramBot(req.body);
      res.json(bot);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/telegram-bots/:id", async (req, res) => {
    try {
      const bot = await storage.updateTelegramBot(req.params.id, req.body);
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }
      res.json(bot);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/telegram-bots/:id", async (req, res) => {
    try {
      const success = await storage.deleteTelegramBot(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Bot not found" });
      }
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Author Info endpoints
  app.get("/api/author", async (req, res) => {
    try {
      const author = await storage.getAuthorInfo();
      res.json(author);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/author", async (req, res) => {
    try {
      const author = await storage.createOrUpdateAuthorInfo(req.body);
      res.json(author);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  return httpServer;
}
