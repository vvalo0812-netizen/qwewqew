import { spawn, ChildProcess } from 'child_process';
import { EventEmitter } from 'events';
import path from 'path';
import fs from 'fs';

export interface TerminalSession {
  id: string;
  process: ChildProcess;
  emitter: EventEmitter;
  isActive: boolean;
}

class TerminalService {
  private sessions: Map<string, TerminalSession> = new Map();
  private toolsDirectory = path.join(process.cwd(), 'tools');

  constructor() {
    this.ensureToolsDirectory();
  }

  private ensureToolsDirectory() {
    if (!fs.existsSync(this.toolsDirectory)) {
      fs.mkdirSync(this.toolsDirectory, { recursive: true });
    }
  }

  createSession(sessionId: string): TerminalSession {
    if (this.sessions.has(sessionId)) {
      this.destroySession(sessionId);
    }

    const emitter = new EventEmitter();
    
    // Create a bash session
    const shellProcess = spawn('bash', [], {
      cwd: this.toolsDirectory,
      env: { ...process.env, TERM: 'xterm-256color' }
    });

    const session: TerminalSession = {
      id: sessionId,
      process: shellProcess,
      emitter,
      isActive: true
    };

    // Handle process output
    shellProcess.stdout?.on('data', (data) => {
      emitter.emit('output', data.toString());
    });

    shellProcess.stderr?.on('data', (data) => {
      emitter.emit('output', data.toString());
    });

    shellProcess.on('close', (code) => {
      emitter.emit('output', `\nProcess exited with code ${code}\n`);
      session.isActive = false;
    });

    shellProcess.on('error', (error) => {
      emitter.emit('output', `Error: ${error.message}\n`);
    });

    this.sessions.set(sessionId, session);
    
    // Send welcome message
    emitter.emit('output', `крис@osint-platform:${this.toolsDirectory}$ `);
    
    return session;
  }

  executeCommand(sessionId: string, command: string): boolean {
    const session = this.sessions.get(sessionId);
    if (!session || !session.isActive) {
      return false;
    }

    // Security: Basic command filtering
    const dangerousCommands = ['rm -rf', 'sudo', 'su', 'chmod 777', 'mkfs'];
    const isDangerous = dangerousCommands.some(cmd => command.includes(cmd));
    
    if (isDangerous) {
      session.emitter.emit('output', 'Error: Command not allowed for security reasons\n');
      session.emitter.emit('output', `крис@osint-platform:${this.toolsDirectory}$ `);
      return false;
    }

    try {
      session.process.stdin?.write(command + '\n');
      return true;
    } catch (error: any) {
      session.emitter.emit('output', `Error executing command: ${error.message}\n`);
      return false;
    }
  }

  getSession(sessionId: string): TerminalSession | undefined {
    return this.sessions.get(sessionId);
  }

  destroySession(sessionId: string): boolean {
    const session = this.sessions.get(sessionId);
    if (!session) {
      return false;
    }

    session.isActive = false;
    session.process.kill();
    session.emitter.removeAllListeners();
    this.sessions.delete(sessionId);
    
    return true;
  }

  async executeOSINTTool(toolName: string, target: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const sessionId = `osint-${Date.now()}`;
      const session = this.createSession(sessionId);
      
      let output = '';
      
      session.emitter.on('output', (data) => {
        output += data;
      });

      // Execute the OSINT tool based on type
      let command = '';
      switch (toolName) {
        case 'phone_lookup':
          command = `python3 -c "import phonenumbers; from phonenumbers import carrier, geocoder; num = phonenumbers.parse('${target}'); print(f'Carrier: {carrier.name_for_number(num, \\"en\\")}'); print(f'Location: {geocoder.description_for_number(num, \\"en\\")}')"`;
          break;
        case 'whois_lookup':
          command = `whois ${target}`;
          break;
        case 'dns_lookup':
          command = `nslookup ${target}`;
          break;
        default:
          reject(new Error(`Unknown OSINT tool: ${toolName}`));
          return;
      }

      setTimeout(() => {
        this.executeCommand(sessionId, command);
      }, 100);

      // Cleanup after 30 seconds
      setTimeout(() => {
        this.destroySession(sessionId);
        resolve(output);
      }, 30000);
    });
  }
}

export const terminalService = new TerminalService();
