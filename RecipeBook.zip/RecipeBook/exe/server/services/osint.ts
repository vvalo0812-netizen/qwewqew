import { exec } from 'child_process';
import { promisify } from 'util';
import dns from 'dns';
import { aiService } from './ai.js';

const execAsync = promisify(exec);

export interface OSINTResult {
  target: string;
  type: string;
  results: any;
  timestamp: string;
  status: 'success' | 'error';
  error?: string;
}

class OSINTService {
  async analyzePhone(phoneNumber: string): Promise<OSINTResult> {
    const result: OSINTResult = {
      target: phoneNumber,
      type: 'phone',
      results: {},
      timestamp: new Date().toISOString(),
      status: 'success'
    };

    try {
      // Basic phone number validation and formatting
      const cleanNumber = phoneNumber.replace(/[^\d+]/g, '');
      
      result.results = {
        formatted: cleanNumber,
        isValid: cleanNumber.length >= 10,
        analysis: await aiService.analyzeWithAI('grok', phoneNumber, 'phone')
      };

      // Try to get carrier info using Python phonenumbers library
      try {
        const { stdout } = await execAsync(`python3 -c "
import phonenumbers
from phonenumbers import carrier, geocoder
try:
    num = phonenumbers.parse('${cleanNumber}')
    print(f'Carrier: {carrier.name_for_number(num, \"en\")}')
    print(f'Location: {geocoder.description_for_number(num, \"en\")}')
    print(f'Valid: {phonenumbers.is_valid_number(num)}')
except:
    print('Error: Invalid phone number format')
"`);
        result.results.carrierInfo = stdout.trim();
      } catch (error) {
        result.results.carrierInfo = 'Carrier lookup service unavailable';
      }

    } catch (error: any) {
      result.status = 'error';
      result.error = error.message;
    }

    return result;
  }

  async analyzeDomain(domain: string): Promise<OSINTResult> {
    const result: OSINTResult = {
      target: domain,
      type: 'domain',
      results: {},
      timestamp: new Date().toISOString(),
      status: 'success'
    };

    try {
      // DNS lookup
      const dnsPromises = [
        this.getDNSRecords(domain, 'A'),
        this.getDNSRecords(domain, 'MX'),
        this.getDNSRecords(domain, 'NS'),
        this.getDNSRecords(domain, 'TXT')
      ];

      const [aRecords, mxRecords, nsRecords, txtRecords] = await Promise.allSettled(dnsPromises);

      result.results.dns = {
        A: aRecords.status === 'fulfilled' ? aRecords.value : [],
        MX: mxRecords.status === 'fulfilled' ? mxRecords.value : [],
        NS: nsRecords.status === 'fulfilled' ? nsRecords.value : [],
        TXT: txtRecords.status === 'fulfilled' ? txtRecords.value : []
      };

      // WHOIS lookup
      try {
        const { stdout: whoisOutput } = await execAsync(`whois ${domain}`);
        result.results.whois = whoisOutput;
      } catch (error) {
        result.results.whois = 'WHOIS lookup failed';
      }

      // AI analysis
      result.results.analysis = await aiService.analyzeWithAI('grok', domain, 'domain');

    } catch (error: any) {
      result.status = 'error';
      result.error = error.message;
    }

    return result;
  }

  async analyzeSocialMedia(username: string): Promise<OSINTResult> {
    const result: OSINTResult = {
      target: username,
      type: 'social',
      results: {},
      timestamp: new Date().toISOString(),
      status: 'success'
    };

    try {
      // Clean username
      const cleanUsername = username.replace(/[@#]/g, '');
      
      // Common social media platforms
      const platforms = [
        { name: 'Twitter', url: `https://twitter.com/${cleanUsername}` },
        { name: 'Instagram', url: `https://instagram.com/${cleanUsername}` },
        { name: 'GitHub', url: `https://github.com/${cleanUsername}` },
        { name: 'LinkedIn', url: `https://linkedin.com/in/${cleanUsername}` },
        { name: 'TikTok', url: `https://tiktok.com/@${cleanUsername}` },
        { name: 'YouTube', url: `https://youtube.com/@${cleanUsername}` }
      ];

      result.results.platforms = platforms;
      result.results.analysis = await aiService.analyzeWithAI('grok', username, 'social');

    } catch (error: any) {
      result.status = 'error';
      result.error = error.message;
    }

    return result;
  }

  async analyzeEmail(email: string): Promise<OSINTResult> {
    const result: OSINTResult = {
      target: email,
      type: 'email',
      results: {},
      timestamp: new Date().toISOString(),
      status: 'success'
    };

    try {
      const [localPart, domain] = email.split('@');
      
      if (!domain) {
        throw new Error('Invalid email format');
      }

      // Basic validation
      result.results.validation = {
        format: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),
        localPart,
        domain
      };

      // Domain analysis
      const domainAnalysis = await this.analyzeDomain(domain);
      result.results.domainInfo = domainAnalysis.results;

      // AI analysis
      result.results.analysis = await aiService.analyzeWithAI('grok', email, 'email');

    } catch (error: any) {
      result.status = 'error';
      result.error = error.message;
    }

    return result;
  }

  private async getDNSRecords(domain: string, type: string): Promise<any[]> {
    return new Promise((resolve, reject) => {
      const resolver = new dns.Resolver();
      
      switch (type) {
        case 'A':
          resolver.resolve4(domain, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses || []);
          });
          break;
        case 'MX':
          resolver.resolveMx(domain, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses || []);
          });
          break;
        case 'NS':
          resolver.resolveNs(domain, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses || []);
          });
          break;
        case 'TXT':
          resolver.resolveTxt(domain, (err, addresses) => {
            if (err) reject(err);
            else resolve(addresses || []);
          });
          break;
        default:
          reject(new Error(`Unsupported DNS record type: ${type}`));
      }
    });
  }
}

export const osintService = new OSINTService();
