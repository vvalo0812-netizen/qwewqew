import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, json, boolean, serial, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const analysisResults = pgTable("analysis_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // 'phone', 'domain', 'social', etc.
  target: text("target").notNull(),
  results: json("results"),
  timestamp: timestamp("timestamp").defaultNow(),
  status: text("status").notNull().default('pending'), // 'pending', 'completed', 'failed'
});

export const customTools = pgTable("custom_tools", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  filename: text("filename").notNull(),
  description: text("description"),
  filePath: text("file_path").notNull(),
  isActive: boolean("is_active").default(true),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const aiConversations = pgTable("ai_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messages: json("messages"), // Array of chat messages
  model: text("model").notNull(), // 'grok' or 'deepseek'
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertAnalysisResultSchema = createInsertSchema(analysisResults).pick({
  type: true,
  target: true,
  results: true,
  status: true,
});

export const insertCustomToolSchema = createInsertSchema(customTools).pick({
  name: true,
  filename: true,
  description: true,
  filePath: true,
});

export const insertAIConversationSchema = createInsertSchema(aiConversations).pick({
  messages: true,
  model: true,
});

// Telegram Bots for OSINT
export const telegramBots = pgTable('telegram_bots', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  name: text('name').notNull(),
  username: text('username').notNull(),
  description: text('description').notNull(),
  category: text('category').notNull(),
  features: text('features').array(),
  isActive: boolean('is_active').default(true),
  rating: decimal('rating', { precision: 2, scale: 1 }).default('0.0'),
  addedAt: timestamp('added_at').defaultNow(),
});

// Author information
export const authorInfo = pgTable('author_info', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  name: text('name').notNull(),
  title: text('title').notNull(),
  bio: text('bio').notNull(),
  skills: text('skills').array(),
  achievements: text('achievements').array(),
  socialLinks: jsonb('social_links'),
  avatar: text('avatar'),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const insertTelegramBotSchema = createInsertSchema(telegramBots).pick({
  name: true,
  username: true,
  description: true,
  category: true,
  features: true,
  isActive: true,
  rating: true,
});

export const insertAuthorInfoSchema = createInsertSchema(authorInfo).pick({
  name: true,
  title: true,
  bio: true,
  skills: true,
  achievements: true,
  socialLinks: true,
  avatar: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type AnalysisResult = typeof analysisResults.$inferSelect;
export type InsertAnalysisResult = z.infer<typeof insertAnalysisResultSchema>;
export type CustomTool = typeof customTools.$inferSelect;
export type InsertCustomTool = z.infer<typeof insertCustomToolSchema>;
export type AIConversation = typeof aiConversations.$inferSelect;
export type InsertAIConversation = z.infer<typeof insertAIConversationSchema>;
export type TelegramBot = typeof telegramBots.$inferSelect;
export type InsertTelegramBot = z.infer<typeof insertTelegramBotSchema>;
export type AuthorInfo = typeof authorInfo.$inferSelect;
export type InsertAuthorInfo = z.infer<typeof insertAuthorInfoSchema>;
