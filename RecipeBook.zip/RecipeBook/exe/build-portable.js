const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 Building Portable Kris.exe...');

// Create directories
if (!fs.existsSync('app')) fs.mkdirSync('app');
if (!fs.existsSync('build')) fs.mkdirSync('build');

// Copy files to app directory
console.log('📁 Copying application files...');

// Copy main files
fs.copyFileSync('main.js', 'app/main.js');
fs.copyFileSync('preload.js', 'app/preload.js');
fs.copyFileSync('server.js', 'app/server.js');
fs.copyFileSync('icon.png', 'app/icon.png');

// Copy package.json for app
const appPackage = {
  "name": "kris-osint",
  "version": "1.0.0",
  "main": "main.js",
  "dependencies": {
    "electron": "^28.0.0",
    "electron-serve": "^1.1.0",
    "express": "^4.18.2"
  }
};
fs.writeFileSync('app/package.json', JSON.stringify(appPackage, null, 2));

// Copy dist directory
if (fs.existsSync('dist')) {
  const copyDir = (src, dest) => {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    const entries = fs.readdirSync(src, { withFileTypes: true });
    
    for (let entry of entries) {
      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);
      
      if (entry.isDirectory()) {
        copyDir(srcPath, destPath);
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  };
  
  copyDir('dist', 'app/dist');
  console.log('✅ Frontend files copied');
}

// Install dependencies in app folder
console.log('📦 Installing app dependencies...');
try {
  execSync('npm install --production', { 
    cwd: path.join(__dirname, 'app'),
    stdio: 'inherit'
  });
} catch (error) {
  console.error('Error installing dependencies:', error.message);
}

// Build executable
console.log('⚡ Building executable...');
try {
  execSync('npx electron-builder --config.directories.app=app --config.win.artifactName=kris.exe --config.win.target=portable', {
    stdio: 'inherit'
  });
  console.log('🎉 ✨ kris.exe successfully built! ✨');
  console.log('📍 Location: exe/dist/kris.exe');
  console.log('🔑 Password: Kris');
} catch (error) {
  console.error('Build failed:', error.message);
}