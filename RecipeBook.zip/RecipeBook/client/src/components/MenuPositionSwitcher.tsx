import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import { 
  Layout, 
  LayoutGrid,
  ArrowLeft,
  ArrowRight, 
  ArrowUp,
  ArrowDown
} from 'lucide-react';

export type MenuPosition = 'left' | 'right' | 'top' | 'bottom';

interface MenuPositionSwitcherProps {
  currentPosition: MenuPosition;
  onPositionChange: (position: MenuPosition) => void;
}

const positions = [
  { 
    id: 'left' as MenuPosition, 
    name: 'Слева', 
    icon: ArrowLeft,
    description: 'Классическое боковое меню'
  },
  { 
    id: 'right' as MenuPosition, 
    name: 'Справа', 
    icon: ArrowRight,
    description: 'Меню с правой стороны'
  },
  { 
    id: 'top' as MenuPosition, 
    name: 'Сверху', 
    icon: ArrowUp,
    description: 'Горизонтальное меню сверху'
  },
  { 
    id: 'bottom' as MenuPosition, 
    name: 'Снизу', 
    icon: ArrowDown,
    description: 'Меню в нижней части'
  }
];

export default function MenuPositionSwitcher({ 
  currentPosition, 
  onPositionChange 
}: MenuPositionSwitcherProps) {
  const [isOpen, setIsOpen] = useState(false);

  const currentPositionData = positions.find(p => p.id === currentPosition);

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="gap-2 bg-gray-800/50 border-gray-600 hover:bg-gray-700/50 text-white"
          data-testid="button-menu-position"
        >
          <LayoutGrid className="w-4 h-4" />
          <span className="hidden sm:inline">Позиция меню</span>
        </Button>
      </PopoverTrigger>
      
      <PopoverContent className="w-80 bg-gray-900 border-gray-700" align="end">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Layout className="w-5 h-5 text-purple-400" />
            <h3 className="font-semibold text-white">Позиция меню</h3>
          </div>
          
          <p className="text-sm text-gray-400">
            Выберите где отображать навигационное меню
          </p>

          <div className="grid grid-cols-2 gap-2">
            {positions.map((position) => {
              const Icon = position.icon;
              const isActive = currentPosition === position.id;
              
              return (
                <Button
                  key={position.id}
                  variant={isActive ? "default" : "outline"}
                  className={`h-auto p-4 flex flex-col gap-2 ${
                    isActive 
                      ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white border-purple-500' 
                      : 'bg-gray-800 border-gray-600 hover:bg-gray-700 text-gray-300'
                  }`}
                  onClick={() => {
                    onPositionChange(position.id);
                    setIsOpen(false);
                  }}
                  data-testid={`button-position-${position.id}`}
                >
                  <Icon className="w-6 h-6" />
                  <div className="text-center">
                    <div className="font-medium text-sm">{position.name}</div>
                    <div className="text-xs opacity-70 mt-1">{position.description}</div>
                  </div>
                </Button>
              );
            })}
          </div>

          {/* Preview */}
          <div className="border border-gray-700 rounded-lg p-3 bg-gray-800/50">
            <div className="text-xs text-gray-400 mb-2">Предварительный просмотр:</div>
            <div className="relative w-full h-16 bg-gray-700 rounded border border-gray-600">
              {/* Menu representation */}
              {currentPosition === 'left' && (
                <div className="absolute left-0 top-0 bottom-0 w-4 bg-gradient-to-r from-purple-500 to-blue-500 rounded-l"></div>
              )}
              {currentPosition === 'right' && (
                <div className="absolute right-0 top-0 bottom-0 w-4 bg-gradient-to-r from-purple-500 to-blue-500 rounded-r"></div>
              )}
              {currentPosition === 'top' && (
                <div className="absolute top-0 left-0 right-0 h-4 bg-gradient-to-r from-purple-500 to-blue-500 rounded-t"></div>
              )}
              {currentPosition === 'bottom' && (
                <div className="absolute bottom-0 left-0 right-0 h-4 bg-gradient-to-r from-purple-500 to-blue-500 rounded-b"></div>
              )}
              
              {/* Content area */}
              <div className="absolute inset-1 bg-gray-600 rounded flex items-center justify-center">
                <div className="text-xs text-gray-300">Контент</div>
              </div>
            </div>
          </div>

          <div className="text-xs text-gray-500 text-center">
            💡 Выберите удобную для вас позицию меню
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}