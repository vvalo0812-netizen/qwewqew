import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Upload, File, Play, Trash2, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CustomTool {
  id: string;
  name: string;
  filename: string;
  description: string;
  isActive: boolean;
  uploadedAt: string;
}

export default function FileManager() {
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [toolName, setToolName] = useState('');
  const [toolDescription, setToolDescription] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: tools, isLoading } = useQuery<CustomTool[]>({
    queryKey: ['/api/tools'],
  });

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await apiRequest('POST', '/api/tools/upload', formData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tools'] });
      setUploadDialogOpen(false);
      setToolName('');
      setToolDescription('');
      setSelectedFile(null);
      toast({
        title: "Success",
        description: "Tool uploaded successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const executeMutation = useMutation({
    mutationFn: async ({ toolId, args }: { toolId: string; args: string }) => {
      const response = await apiRequest('POST', '/api/tools/execute', { toolId, args });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Tool Executed",
        description: `${data.tool} completed successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Execution Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      if (!toolName) {
        setToolName(file.name.replace(/\.[^/.]+$/, ''));
      }
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;

    const formData = new FormData();
    formData.append('tool', selectedFile);
    formData.append('name', toolName);
    formData.append('description', toolDescription);

    uploadMutation.mutate(formData);
  };

  const handleExecute = (toolId: string, toolName: string) => {
    const args = prompt(`Enter arguments for ${toolName}:`);
    if (args !== null) {
      executeMutation.mutate({ toolId, args });
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-semibold">File Manager</h2>
          <p className="text-muted-foreground">Upload and manage custom OSINT tools</p>
        </div>
        
        <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-upload-tool">
              <Plus className="w-4 h-4 mr-2" />
              Upload Tool
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Upload Custom Tool</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleUpload} className="space-y-4">
              <div>
                <Label htmlFor="file">File</Label>
                <Input
                  id="file"
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  accept=".py,.js,.sh,.txt"
                  required
                  data-testid="input-file-upload"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Supported formats: .py, .js, .sh, .txt
                </p>
              </div>
              
              <div>
                <Label htmlFor="name">Tool Name</Label>
                <Input
                  id="name"
                  value={toolName}
                  onChange={(e) => setToolName(e.target.value)}
                  required
                  data-testid="input-tool-name"
                />
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={toolDescription}
                  onChange={(e) => setToolDescription(e.target.value)}
                  placeholder="Describe what this tool does..."
                  data-testid="textarea-tool-description"
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setUploadDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={uploadMutation.isPending}
                  data-testid="button-upload-submit"
                >
                  {uploadMutation.isPending ? 'Uploading...' : 'Upload'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Upload Area */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div 
            className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors"
            onClick={() => fileInputRef.current?.click()}
            data-testid="dropzone-upload"
          >
            <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-lg font-medium mb-2">Drop files here or click to browse</p>
            <p className="text-muted-foreground">
              Upload Python scripts, shell scripts, or other OSINT tools
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Tools List */}
      <Card>
        <CardHeader>
          <CardTitle>Custom Tools ({tools?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">Loading tools...</div>
          ) : tools && tools.length > 0 ? (
            <div className="space-y-4">
              {tools.map((tool) => (
                <div 
                  key={tool.id} 
                  className="flex items-center justify-between p-4 bg-secondary rounded-lg"
                  data-testid={`tool-${tool.id}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <File className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">{tool.name}</h4>
                      <p className="text-sm text-muted-foreground">{tool.filename}</p>
                      {tool.description && (
                        <p className="text-sm text-muted-foreground mt-1">{tool.description}</p>
                      )}
                      <p className="text-xs text-muted-foreground">
                        Uploaded: {new Date(tool.uploadedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Badge variant={tool.isActive ? "default" : "secondary"}>
                      {tool.isActive ? "Active" : "Inactive"}
                    </Badge>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleExecute(tool.id, tool.name)}
                      disabled={!tool.isActive || executeMutation.isPending}
                      data-testid={`button-execute-${tool.id}`}
                    >
                      <Play className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-destructive hover:text-destructive"
                      data-testid={`button-delete-${tool.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <File className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <p className="text-muted-foreground">No custom tools uploaded yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Upload your first OSINT tool to get started
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
