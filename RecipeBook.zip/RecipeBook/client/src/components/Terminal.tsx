import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useTerminal } from '@/hooks/useTerminal';

export default function Terminal() {
  const terminalRef = useRef<HTMLDivElement>(null);
  const [command, setCommand] = useState('');
  const { output, sendCommand, isConnected } = useTerminal();

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [output]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (command.trim() && isConnected) {
      sendCommand(command);
      setCommand('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit(e);
    }
  };

  return (
    <div className="h-full flex flex-col bg-black text-green-400 font-mono">
      {/* Terminal Output */}
      <div 
        ref={terminalRef}
        className="flex-1 p-4 overflow-y-auto whitespace-pre-wrap text-sm"
        data-testid="terminal-output"
      >
        {output || 'Connecting to terminal...'}
      </div>

      {/* Command Input */}
      <div className="border-t border-gray-700 p-3">
        <form onSubmit={handleSubmit} className="flex space-x-2">
          <span className="text-green-400 self-center">$</span>
          <Input
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Enter command..."
            className="flex-1 bg-black border-gray-700 text-green-400 focus:border-green-500"
            disabled={!isConnected}
            data-testid="input-terminal-command"
          />
          <Button 
            type="submit" 
            variant="outline" 
            disabled={!isConnected || !command.trim()}
            data-testid="button-execute-command"
          >
            Execute
          </Button>
        </form>
        {!isConnected && (
          <p className="text-red-400 text-xs mt-2">Disconnected from terminal</p>
        )}
      </div>
    </div>
  );
}
