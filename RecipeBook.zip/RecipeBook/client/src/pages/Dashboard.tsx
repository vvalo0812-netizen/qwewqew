import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import Terminal from "@/components/Terminal";
import AIChat from "@/components/AIChat";
import FileManager from "@/components/FileManager";
import OSINTTools from "@/components/OSINTTools";
import TelegramBots from "@/pages/TelegramBots";
import AuthorInfo from "@/pages/AuthorInfo";
import MusicServices from "@/pages/MusicServices";
import MenuPositionSwitcher, { type MenuPosition } from "@/components/MenuPositionSwitcher";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Clock, Bell, ChevronUp, ChevronDown, Settings } from "lucide-react";

type ActiveView = 'overview' | 'phone' | 'web' | 'social' | 'files' | 'terminal' | 'ai-chat' | 'telegram-bots' | 'author' | 'music';

export default function Dashboard() {
  const [activeView, setActiveView] = useState<ActiveView>('overview');
  const [terminalCollapsed, setTerminalCollapsed] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [menuPosition, setMenuPosition] = useState<MenuPosition>('left');

  const { data: providers = [] } = useQuery({
    queryKey: ['/api/ai/providers'],
  });

  const { data: analysisHistory = [] } = useQuery({
    queryKey: ['/api/osint/history'],
  });

  const handleAnalyze = async () => {
    if (!searchQuery.trim()) return;
    
    // Determine analysis type based on input
    let type = 'general';
    if (searchQuery.includes('@')) type = 'email';
    else if (searchQuery.match(/^\+?[\d\s\-\(\)]+$/)) type = 'phone';
    else if (searchQuery.match(/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)) type = 'domain';
    else if (searchQuery.startsWith('@')) type = 'social';

    // TODO: Implement analysis API call
    console.log('Analyzing:', searchQuery, 'Type:', type);
  };

  const renderMainContent = () => {
    switch (activeView) {
      case 'phone':
      case 'web':
      case 'social':
        return <OSINTTools type={activeView} />;
      case 'files':
        return <FileManager />;
      case 'terminal':
        return <Terminal />;
      case 'ai-chat':
        return <AIChat />;
      case 'telegram-bots':
        return <TelegramBots />;
      case 'author':
        return <AuthorInfo />;
      case 'music':
        return <MusicServices />;
      default:
        return (
          <div className="p-6">
            {/* Quick Actions */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card 
                  className="cursor-pointer hover:border-primary transition-colors"
                  onClick={() => setActiveView('phone')}
                  data-testid="card-phone-analysis"
                >
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-phone text-primary"></i>
                      </div>
                      <div>
                        <h4 className="font-medium">Phone Lookup</h4>
                        <p className="text-sm text-muted-foreground">Analyze phone numbers</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card 
                  className="cursor-pointer hover:border-primary transition-colors"
                  onClick={() => setActiveView('web')}
                  data-testid="card-domain-analysis"
                >
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-search text-primary"></i>
                      </div>
                      <div>
                        <h4 className="font-medium">Domain Check</h4>
                        <p className="text-sm text-muted-foreground">Website analysis</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card 
                  className="cursor-pointer hover:border-primary transition-colors"
                  onClick={() => setActiveView('social')}
                  data-testid="card-social-analysis"
                >
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-user-secret text-primary"></i>
                      </div>
                      <div>
                        <h4 className="font-medium">Social Recon</h4>
                        <p className="text-sm text-muted-foreground">Social media analysis</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card 
                  className="cursor-pointer hover:border-primary transition-colors"
                  onClick={() => setActiveView('files')}
                  data-testid="card-file-upload"
                >
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-upload text-primary"></i>
                      </div>
                      <div>
                        <h4 className="font-medium">File Upload</h4>
                        <p className="text-sm text-muted-foreground">Upload custom tools</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* AI-Powered Analysis */}
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>AI-Powered Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex space-x-3">
                    <Input
                      placeholder="Enter target for analysis (phone, email, domain, username...)"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-1"
                      data-testid="input-search-query"
                    />
                    <Button onClick={handleAnalyze} data-testid="button-analyze">
                      <i className="fas fa-search mr-2"></i>
                      Analyze
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <span className="text-sm text-muted-foreground">Quick examples:</span>
                    <Button 
                      variant="secondary" 
                      size="sm" 
                      onClick={() => setSearchQuery('+1234567890')}
                      data-testid="button-example-phone"
                    >
                      +1234567890
                    </Button>
                    <Button 
                      variant="secondary" 
                      size="sm" 
                      onClick={() => setSearchQuery('example.com')}
                      data-testid="button-example-domain"
                    >
                      example.com
                    </Button>
                    <Button 
                      variant="secondary" 
                      size="sm" 
                      onClick={() => setSearchQuery('@username')}
                      data-testid="button-example-username"
                    >
                      @username
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                {Array.isArray(analysisHistory) && analysisHistory.length > 0 ? (
                  <div className="space-y-4">
                    {analysisHistory.slice(0, 5).map((activity: any) => (
                      <div key={activity.id} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                            <i className={`fas fa-${activity.type === 'phone' ? 'phone' : activity.type === 'domain' ? 'globe' : 'user'} text-primary text-sm`}></i>
                          </div>
                          <div>
                            <p className="font-medium">{activity.type} analysis: {activity.target}</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(activity.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <Badge variant={activity.status === 'completed' ? 'default' : 'destructive'}>
                          {activity.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">No analysis history yet</p>
                )}
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  const getLayoutClasses = () => {
    switch (menuPosition) {
      case 'left':
        return 'flex flex-row h-screen';
      case 'right':
        return 'flex flex-row-reverse h-screen';
      case 'top':
        return 'flex flex-col h-screen';
      case 'bottom':
        return 'flex flex-col-reverse h-screen';
      default:
        return 'flex flex-row h-screen';
    }
  };

  const getMainClasses = () => {
    switch (menuPosition) {
      case 'top':
      case 'bottom':
        return 'flex-1 overflow-hidden';
      default:
        return 'flex-1 flex flex-col overflow-hidden';
    }
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header with menu position switcher */}
      <div className="flex items-center justify-between p-4 border-b border-border bg-card">
        <div className="flex items-center gap-4">
          <h1 className="text-xl font-bold text-gradient">Sora</h1>
          <span className="text-2xl">空</span>
        </div>
        <MenuPositionSwitcher 
          currentPosition={menuPosition}
          onPositionChange={setMenuPosition}
        />
      </div>

      <div className={getLayoutClasses()}>
        <Sidebar 
          activeView={activeView} 
          onViewChange={(view: string) => setActiveView(view as ActiveView)}
          providers={Array.isArray(providers) ? providers : []}
          position={menuPosition}
        />
        
        <main className={getMainClasses()}>
        {/* Top Bar */}
        <header className="bg-card border-b border-border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h2 className="text-xl font-semibold">OSINT Dashboard</h2>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span data-testid="text-current-time">
                  {new Date().toLocaleTimeString()}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2 px-3 py-1 bg-secondary rounded-full">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm">Ready</span>
              </div>
              <Button variant="ghost" size="sm" data-testid="button-notifications">
                <Bell className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-auto">
          {renderMainContent()}
        </div>

        {/* Terminal Panel */}
        {!terminalCollapsed && (
          <div className="border-t border-border bg-card">
            <div 
              className="flex items-center justify-between p-3 cursor-pointer"
              onClick={() => setTerminalCollapsed(!terminalCollapsed)}
              data-testid="button-toggle-terminal"
            >
              <div className="flex items-center space-x-3">
                <i className="fas fa-terminal text-primary"></i>
                <h3 className="font-medium">Terminal</h3>
                <Badge variant="secondary">Ready</Badge>
              </div>
              {terminalCollapsed ? <ChevronUp /> : <ChevronDown />}
            </div>
            
            <div className="h-64">
              <Terminal />
            </div>
          </div>
        )}
      </main>
      </div>
    </div>
  );
}
