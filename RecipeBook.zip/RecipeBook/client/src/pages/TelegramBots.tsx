import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { apiRequest } from '@/lib/queryClient';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Plus, Star, Users, Bot, ExternalLink, Zap } from 'lucide-react';
import { queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { TelegramBot } from '@shared/schema';

const botSchema = z.object({
  name: z.string().min(1, 'Название обязательно'),
  username: z.string().min(1, 'Username обязателен').startsWith('@', 'Username должен начинаться с @'),
  description: z.string().min(10, 'Описание должно содержать минимум 10 символов'),
  category: z.string().min(1, 'Категория обязательна'),
  features: z.array(z.string()).min(1, 'Добавьте хотя бы одну функцию'),
  rating: z.string().optional(),
});

type BotFormData = z.infer<typeof botSchema>;

const categoryColors = {
  'Поиск людей': 'bg-purple-500',
  'Анализ и мониторинг': 'bg-blue-500',
  'Универсальный': 'bg-green-500',
  'Расследования': 'bg-red-500',
  'Информационный анализ': 'bg-yellow-500',
  'Этичный OSINT': 'bg-cyan-500',
  'Социальные сети': 'bg-pink-500',
  'Поведенческий анализ': 'bg-orange-500',
  'Оперативный анализ': 'bg-indigo-500',
  'Статистика': 'bg-teal-500',
  'Социальный граф': 'bg-violet-500',
  'Юридический анализ': 'bg-amber-500'
};

export default function TelegramBots() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const { toast } = useToast();

  const { data: bots = [], isLoading } = useQuery<TelegramBot[]>({
    queryKey: ['/api/telegram-bots'],
  });

  const form = useForm<BotFormData>({
    resolver: zodResolver(botSchema),
    defaultValues: {
      name: '',
      username: '@',
      description: '',
      category: '',
      features: [],
      rating: '0.0',
    },
  });

  const createBotMutation = useMutation({
    mutationFn: async (data: BotFormData) => {
      const response = await fetch('/api/telegram-bots', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to create bot');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/telegram-bots'] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: 'Успешно!',
        description: 'Telegram бот добавлен в каталог',
      });
    },
    onError: () => {
      toast({
        title: 'Ошибка',
        description: 'Не удалось добавить бота',
        variant: 'destructive',
      });
    },
  });

  const filteredBots = bots.filter((bot) => {
    const matchesSearch = bot.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         bot.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         bot.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || bot.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = Array.from(new Set(bots.map((bot) => bot.category)));

  const onSubmit = (data: BotFormData) => {
    createBotMutation.mutate(data);
  };

  const addFeature = () => {
    const features = form.getValues('features');
    form.setValue('features', [...features, '']);
  };

  const updateFeature = (index: number, value: string) => {
    const features = form.getValues('features');
    features[index] = value;
    form.setValue('features', features);
  };

  const removeFeature = (index: number) => {
    const features = form.getValues('features');
    form.setValue('features', features.filter((_, i) => i !== index));
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-700 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-64 bg-gray-700 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gradient flex items-center gap-3">
            <Bot className="w-8 h-8" />
            Telegram OSINT Боты
          </h1>
          <p className="text-muted-foreground mt-2">
            Коллекция лучших Telegram ботов для OSINT расследований
          </p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700" data-testid="button-add-bot">
              <Plus className="w-4 h-4 mr-2" />
              Добавить бота
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Добавить Telegram бота</DialogTitle>
            </DialogHeader>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Название бота</FormLabel>
                      <FormControl>
                        <Input placeholder="Например: OSINT Bot" {...field} data-testid="input-bot-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="@username_bot" {...field} data-testid="input-bot-username" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Категория</FormLabel>
                      <FormControl>
                        <Input placeholder="Например: Поиск людей" {...field} data-testid="input-bot-category" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Описание</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Детальное описание возможностей бота..."
                          rows={3}
                          {...field}
                          data-testid="textarea-bot-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel>Функции</FormLabel>
                  <div className="space-y-2 mt-2">
                    {form.watch('features').map((feature, index) => (
                      <div key={index} className="flex gap-2">
                        <Input
                          value={feature}
                          onChange={(e) => updateFeature(index, e.target.value)}
                          placeholder="Описание функции"
                          data-testid={`input-feature-${index}`}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeFeature(index)}
                          data-testid={`button-remove-feature-${index}`}
                        >
                          ✕
                        </Button>
                      </div>
                    ))}
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addFeature}
                      data-testid="button-add-feature"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Добавить функцию
                    </Button>
                  </div>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600"
                    disabled={createBotMutation.isPending}
                    data-testid="button-submit-bot"
                  >
                    {createBotMutation.isPending ? 'Добавление...' : 'Добавить бота'}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                    data-testid="button-cancel"
                  >
                    Отмена
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Input
          placeholder="Поиск ботов..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="sm:max-w-sm"
          data-testid="input-search-bots"
        />
        
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-3 py-2 rounded-md border border-border bg-background text-foreground"
          data-testid="select-category"
        >
          <option value="all">Все категории</option>
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="card-glow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Bot className="w-5 h-5 text-purple-400" />
              <div>
                <p className="text-sm text-muted-foreground">Всего ботов</p>
                <p className="text-2xl font-bold text-gradient">{bots.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-glow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-blue-400" />
              <div>
                <p className="text-sm text-muted-foreground">Категорий</p>
                <p className="text-2xl font-bold text-gradient">{categories.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-glow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-yellow-400" />
              <div>
                <p className="text-sm text-muted-foreground">Средний рейтинг</p>
                <p className="text-2xl font-bold text-gradient">
                  {bots.length > 0 ? (bots.reduce((acc, bot) => acc + parseFloat(bot.rating || '0'), 0) / bots.length).toFixed(1) : '0.0'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-glow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Zap className="w-5 h-5 text-green-400" />
              <div>
                <p className="text-sm text-muted-foreground">Активные</p>
                <p className="text-2xl font-bold text-gradient">
                  {bots.filter((bot) => bot.isActive).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bots Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBots.map((bot) => (
          <Card key={bot.id} className="rainbow-border hover:shadow-lg transition-all duration-300 group">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg group-hover:text-gradient transition-all duration-300">
                    {bot.name}
                  </CardTitle>
                  <p className="text-muted-foreground font-mono text-sm">{bot.username}</p>
                </div>
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-sm font-medium">{bot.rating}</span>
                </div>
              </div>
              
              <Badge 
                className={`w-fit text-white ${categoryColors[bot.category as keyof typeof categoryColors] || 'bg-gray-500'}`}
              >
                {bot.category}
              </Badge>
            </CardHeader>

            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground leading-relaxed">
                {bot.description}
              </p>

              <div>
                <p className="text-sm font-medium mb-2">Возможности:</p>
                <div className="flex flex-wrap gap-1">
                  {bot.features?.slice(0, 3).map((feature, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                  {bot.features && bot.features.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{bot.features.length - 3} еще
                    </Badge>
                  )}
                </div>
              </div>

              <Button 
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                onClick={() => window.open(`https://t.me/${bot.username.replace('@', '')}`, '_blank')}
                data-testid={`button-open-bot-${bot.id}`}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Перейти к боту
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredBots.length === 0 && (
        <div className="text-center py-12">
          <Bot className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-muted-foreground">
            {searchQuery || selectedCategory !== 'all' ? 'Боты не найдены' : 'Нет доступных ботов'}
          </h3>
          <p className="text-sm text-muted-foreground mt-2">
            {searchQuery || selectedCategory !== 'all' 
              ? 'Попробуйте изменить критерии поиска'
              : 'Добавьте первого бота в коллекцию'
            }
          </p>
        </div>
      )}
    </div>
  );
}