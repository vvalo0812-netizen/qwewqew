# Крис - AI-Powered OSINT Platform

## Overview

This is a comprehensive OSINT (Open Source Intelligence) platform named "Крис" that combines artificial intelligence capabilities with intelligence gathering tools. The platform provides a unified interface for conducting various types of investigations including phone number analysis, web reconnaissance, social media research, and general data collection. The system features dual AI models (Grok and DeepSeek) working together to assist with information gathering and analysis.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript in a Vite-based development environment
- **UI Library**: Comprehensive shadcn/ui component system with Radix UI primitives
- **Styling**: Tailwind CSS with a dark-themed cyberpunk aesthetic featuring purple and blue gradients
- **State Management**: TanStack Query for server state management and React hooks for local state
- **Routing**: Wouter for lightweight client-side routing
- **Component Structure**: Modular design with dedicated components for AI chat, terminal interface, file management, and OSINT tools

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with WebSocket support for real-time terminal communication
- **File Handling**: Multer middleware for file uploads with 10MB size limits
- **Development**: Hot reloading with Vite integration in development mode

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: 
  - Users table for authentication
  - Analysis results table for storing OSINT investigation data
  - Custom tools table for managing uploaded analysis tools
  - AI conversations table for chat history
- **Connection**: Neon Database serverless PostgreSQL adapter
- **Fallback**: In-memory storage implementation for development/testing

### Authentication and Authorization
- **Simple Authentication**: Password-based login system with hardcoded credentials ("Kris")
- **Session Management**: Express sessions with PostgreSQL session storage via connect-pg-simple
- **Frontend Protection**: Route-based authentication state management

### AI Integration Architecture
- **Multi-Provider System**: Pluggable AI service architecture supporting multiple providers
- **Supported Models**:
  - xAI Grok (grok-2-1212, grok-2-vision-1212, grok-beta, grok-vision-beta)
  - DeepSeek (deepseek-chat, deepseek-coder)
- **API Compatibility**: OpenAI-compatible interface for both providers
- **Configuration**: Environment variable-based API key management
- **Chat Interface**: Real-time conversational AI with message history and provider switching

### OSINT Tools Architecture
- **Analysis Types**: Phone number analysis, domain investigation, social media research
- **Python Integration**: External Python scripts for advanced phone number analysis using phonenumbers library
- **Custom Tools**: File upload system for custom analysis scripts and tools
- **Results Storage**: Structured data storage with JSON results and status tracking

### Terminal Integration
- **Real-Time Communication**: WebSocket-based terminal emulation
- **Process Management**: Child process spawning for bash sessions
- **Working Directory**: Dedicated tools directory for custom scripts
- **Session Handling**: Multi-session support with unique session identifiers

## External Dependencies

### AI Services
- **xAI Grok API**: Primary AI model for advanced reasoning and analysis
- **DeepSeek API**: Secondary AI model specializing in coding and technical analysis
- **Configuration**: Requires XAI_API_KEY and DEEPSEEK_API_KEY environment variables

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting
- **Configuration**: Requires DATABASE_URL environment variable
- **Drizzle Kit**: Database migration and schema management

### Development Tools
- **Replit Integration**: Development banner and cartographer plugins for Replit environment
- **Vite Plugins**: Runtime error overlay and development tooling

### UI and Styling
- **Radix UI**: Comprehensive accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Lucide React**: Icon library for consistent iconography
- **Google Fonts**: Inter and Roboto Mono font families

### Utility Libraries
- **TanStack Query**: Server state management and caching
- **date-fns**: Date manipulation and formatting
- **clsx/tailwind-merge**: Conditional CSS class management
- **zod**: Runtime type validation and schema definition
- **multer**: File upload handling middleware