import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ExternalLink, 
  Search, 
  Users, 
  Phone, 
  Mail, 
  Globe, 
  MapPin, 
  Camera, 
  Video, 
  MessageSquare,
  Building,
  Car,
  Shield,
  Zap,
  Calendar,
  Hash,
  FileText,
  Database,
  Lock,
  AlertTriangle
} from 'lucide-react';

interface OSINTSite {
  name: string;
  url: string;
  description: string;
  category: string;
  tags: string[];
  isPremium?: boolean;
  isRestricted?: boolean;
}

const osintSites: OSINTSite[] = [
  // Социальные сети и люди
  { name: 'Pipl', url: 'https://pipl.com', description: 'Поиск людей по имени, email, телефону', category: 'people', tags: ['люди', 'email', 'телефон'] },
  { name: 'WhitePages', url: 'https://whitepages.com', description: 'База данных людей США', category: 'people', tags: ['США', 'адреса', 'телефоны'] },
  { name: 'TruePeopleSearch', url: 'https://truepeoplesearch.com', description: 'Бесплатный поиск людей', category: 'people', tags: ['бесплатный', 'люди'] },
  { name: 'Social Searcher', url: 'https://socialsearcher.com', description: 'Поиск по социальным сетям', category: 'social', tags: ['соцсети', 'мониторинг'] },
  { name: 'Sherlock', url: 'https://sherlock-project.github.io', description: 'Поиск никнеймов по сайтам', category: 'social', tags: ['никнеймы', 'opensource'] },
  { name: 'Namechk', url: 'https://namechk.com', description: 'Проверка доступности никнеймов', category: 'social', tags: ['никнеймы', 'проверка'] },
  
  // Email и коммуникации  
  { name: 'Hunter.io', url: 'https://hunter.io', description: 'Поиск email адресов компаний', category: 'email', tags: ['email', 'компании'], isPremium: true },
  { name: 'Verify Email', url: 'https://verify-email.org', description: 'Проверка существования email', category: 'email', tags: ['email', 'проверка'] },
  { name: 'Have I Been Pwned', url: 'https://haveibeenpwned.com', description: 'Проверка утечек паролей', category: 'email', tags: ['утечки', 'безопасность'] },
  { name: 'Dehashed', url: 'https://dehashed.com', description: 'База данных утечек', category: 'email', tags: ['утечки', 'пароли'], isPremium: true },
  
  // Телефоны
  { name: 'TrueCaller', url: 'https://truecaller.com', description: 'Определение номеров телефонов', category: 'phone', tags: ['телефоны', 'спам'] },
  { name: 'NumberGuru', url: 'https://numberguru.com', description: 'Поиск информации о номерах', category: 'phone', tags: ['телефоны', 'США'] },
  { name: 'PhoneInfoga', url: 'https://github.com/sundowndev/phoneinfoga', description: 'OSINT framework для телефонов', category: 'phone', tags: ['opensource', 'framework'] },
  
  // Домены и IP
  { name: 'Whois', url: 'https://whois.net', description: 'Информация о доменах', category: 'domain', tags: ['домены', 'whois'] },
  { name: 'ViewDNS', url: 'https://viewdns.info', description: 'DNS инструменты', category: 'domain', tags: ['DNS', 'инструменты'] },
  { name: 'DNSdumpster', url: 'https://dnsdumpster.com', description: 'DNS разведка доменов', category: 'domain', tags: ['DNS', 'subdomains'] },
  { name: 'Shodan', url: 'https://shodan.io', description: 'Поисковик интернет-устройств', category: 'domain', tags: ['IoT', 'сканер'], isPremium: true },
  { name: 'Censys', url: 'https://censys.io', description: 'Поиск устройств и сертификатов', category: 'domain', tags: ['сертификаты', 'сканер'] },
  { name: 'BuiltWith', url: 'https://builtwith.com', description: 'Технологии используемые сайтами', category: 'domain', tags: ['технологии', 'анализ'] },
  
  // Геолокация
  { name: 'Google Earth', url: 'https://earth.google.com', description: 'Спутниковые снимки планеты', category: 'geolocation', tags: ['карты', 'спутник'] },
  { name: 'Bing Maps', url: 'https://bing.com/maps', description: 'Карты от Microsoft', category: 'geolocation', tags: ['карты', 'изображения'] },
  { name: 'What3Words', url: 'https://what3words.com', description: 'Адресация по трем словам', category: 'geolocation', tags: ['адреса', 'координаты'] },
  { name: 'GeoGuessr', url: 'https://geoguessr.com', description: 'Определение местоположения по фото', category: 'geolocation', tags: ['фото', 'игра'] },
  
  // Изображения
  { name: 'TinEye', url: 'https://tineye.com', description: 'Обратный поиск изображений', category: 'images', tags: ['изображения', 'поиск'] },
  { name: 'Yandex Images', url: 'https://yandex.ru/images', description: 'Поиск похожих изображений', category: 'images', tags: ['изображения', 'Яндекс'] },
  { name: 'Exif Viewer', url: 'https://exifdata.com', description: 'Просмотр метаданных фото', category: 'images', tags: ['exif', 'метаданные'] },
  
  // Транспорт
  { name: 'FlightRadar24', url: 'https://flightradar24.com', description: 'Отслеживание полетов', category: 'transport', tags: ['самолеты', 'трекинг'] },
  { name: 'MarineTraffic', url: 'https://marinetraffic.com', description: 'Отслеживание кораблей', category: 'transport', tags: ['корабли', 'трекинг'] },
  { name: 'VesselFinder', url: 'https://vesselfinder.com', description: 'Поиск судов', category: 'transport', tags: ['суда', 'морской'] },
  
  // Файлы и документы
  { name: 'FileInfo', url: 'https://fileinfo.com', description: 'Информация о форматах файлов', category: 'files', tags: ['файлы', 'форматы'] },
  { name: 'VirusTotal', url: 'https://virustotal.com', description: 'Анализ файлов на вирусы', category: 'files', tags: ['безопасность', 'вирусы'] },
  { name: 'Any.run', url: 'https://any.run', description: 'Песочница для анализа malware', category: 'files', tags: ['malware', 'анализ'], isPremium: true },
  
  // Криптовалюты
  { name: 'Blockchain.info', url: 'https://blockchain.info', description: 'Исследователь Bitcoin', category: 'crypto', tags: ['bitcoin', 'блокчейн'] },
  { name: 'OXT', url: 'https://oxt.me', description: 'Анализ Bitcoin транзакций', category: 'crypto', tags: ['bitcoin', 'анализ'], isPremium: true },
  { name: 'Crystal', url: 'https://crystalblockchain.com', description: 'Платформа для анализа криптовалют', category: 'crypto', tags: ['анализ', 'compliance'], isPremium: true },
  
  // Даркнет
  { name: 'DarkSearch', url: 'https://darksearch.io', description: 'Поисковик по даркнету', category: 'darkweb', tags: ['tor', 'поиск'], isRestricted: true },
  { name: 'Onion Link', url: 'https://onion.link', description: 'Доступ к .onion сайтам', category: 'darkweb', tags: ['tor', 'прокси'], isRestricted: true },
  
  // Разное
  { name: 'Archive.today', url: 'https://archive.today', description: 'Архив веб-страниц', category: 'misc', tags: ['архив', 'страницы'] },
  { name: 'Wayback Machine', url: 'https://web.archive.org', description: 'Интернет архив', category: 'misc', tags: ['архив', 'история'] },
  { name: 'Pastebin Search', url: 'https://psbdmp.ws', description: 'Поиск по Pastebin', category: 'misc', tags: ['pastebin', 'поиск'] },
];

const categories = [
  { id: 'all', name: 'Все', icon: Search },
  { id: 'people', name: 'Люди', icon: Users },
  { id: 'social', name: 'Соцсети', icon: MessageSquare },
  { id: 'email', name: 'Email', icon: Mail },
  { id: 'phone', name: 'Телефоны', icon: Phone },
  { id: 'domain', name: 'Домены/IP', icon: Globe },
  { id: 'geolocation', name: 'Геолокация', icon: MapPin },
  { id: 'images', name: 'Изображения', icon: Camera },
  { id: 'transport', name: 'Транспорт', icon: Car },
  { id: 'files', name: 'Файлы', icon: FileText },
  { id: 'crypto', name: 'Криптовалюты', icon: Hash },
  { id: 'darkweb', name: 'Даркнет', icon: Lock },
  { id: 'misc', name: 'Разное', icon: Database }
];

export default function OSINTSites() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSites = osintSites.filter(site => {
    const matchesCategory = activeCategory === 'all' || site.category === activeCategory;
    const matchesSearch = site.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         site.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         site.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleSiteClick = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="h-full overflow-auto p-6 space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
            <Search className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gradient">OSINT Framework</h1>
            <p className="text-muted-foreground">Комплексная коллекция инструментов для OSINT разведки</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Поиск инструментов..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Categories */}
      <Tabs value={activeCategory} onValueChange={setActiveCategory} className="space-y-4">
        <TabsList className="flex flex-wrap h-auto p-1 gap-1">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <TabsTrigger 
                key={category.id} 
                value={category.id}
                className="flex items-center gap-2 px-3 py-2"
              >
                <Icon className="w-4 h-4" />
                {category.name}
              </TabsTrigger>
            );
          })}
        </TabsList>

        <TabsContent value={activeCategory} className="space-y-4">
          {/* Stats */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>Найдено: {filteredSites.length} инструментов</span>
            <Badge variant="outline">{osintSites.length} всего</Badge>
          </div>

          {/* Sites Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSites.map((site, index) => (
              <Card 
                key={index} 
                className="group hover:shadow-lg transition-all duration-200 cursor-pointer border-l-4 border-l-orange-500"
                onClick={() => handleSiteClick(site.url)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg flex items-center gap-2">
                        {site.name}
                        <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">
                        {site.description}
                      </p>
                    </div>
                    <div className="flex flex-col gap-1">
                      {site.isPremium && (
                        <Badge variant="secondary" className="text-xs">
                          <Zap className="w-3 h-3 mr-1" />
                          Premium
                        </Badge>
                      )}
                      {site.isRestricted && (
                        <Badge variant="destructive" className="text-xs">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          Осторожно
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex flex-wrap gap-1">
                    {site.tags.slice(0, 3).map((tag, tagIndex) => (
                      <Badge key={tagIndex} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {site.tags.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{site.tags.length - 3}
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredSites.length === 0 && (
            <div className="text-center py-12">
              <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">Ничего не найдено</h3>
              <p className="text-muted-foreground">
                Попробуйте изменить поисковый запрос или выбрать другую категорию
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}