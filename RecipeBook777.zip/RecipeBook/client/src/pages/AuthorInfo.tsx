import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { AuthorInfo as AuthorInfoType } from '@shared/schema';
import { 
  User, 
  Award, 
  Code, 
  Shield, 
  Mail, 
  Github, 
  Linkedin, 
  MessageCircle,
  Star,
  Trophy,
  Brain,
  Target
} from 'lucide-react';

export default function AuthorInfo() {
  const { data: author, isLoading } = useQuery<AuthorInfoType>({
    queryKey: ['/api/author'],
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-32 bg-gray-700 rounded-lg"></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="h-64 bg-gray-700 rounded-lg"></div>
            <div className="h-64 bg-gray-700 rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!author) {
    return (
      <div className="p-6 text-center">
        <User className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-medium text-muted-foreground">
          Информация об авторе недоступна
        </h3>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Hero Section */}
      <Card className="rainbow-border gradient-bg relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-blue-900/20 to-indigo-900/20"></div>
        <CardContent className="relative z-10 p-8">
          <div className="flex flex-col lg:flex-row items-center gap-8">
            <div className="relative">
              <Avatar className="w-32 h-32 border-4 border-white/20 shadow-2xl floating">
                <AvatarImage src={author.avatar || undefined} />
                <AvatarFallback className="text-2xl font-bold bg-gradient-to-br from-purple-500 to-blue-500 text-white">
                  {author.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full border-4 border-white flex items-center justify-center">
                <Shield className="w-4 h-4 text-white" />
              </div>
            </div>

            <div className="text-center lg:text-left space-y-4 flex-1">
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">
                  {author.name}
                </h1>
                <p className="text-xl text-purple-200 font-medium">
                  {author.title}
                </p>
              </div>

              <p className="text-white/90 leading-relaxed max-w-2xl">
                {author.bio}
              </p>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                {/* Amalya */}
                <Card className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500/30">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <Avatar className="w-16 h-16 border-2 border-purple-400">
                        <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white font-bold">
                          A
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-xl font-bold text-white">Amalya</h3>
                        <p className="text-purple-200">Создатель проекта</p>
                        <p className="text-sm text-purple-300">Специалист в комьюнити доксинга/эдиторства</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                        onClick={() => window.open('https://t.me/cluim', '_blank')}
                      >
                        <MessageCircle className="w-4 h-4 mr-2" />
                        @cluim
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                        onClick={() => window.open('https://t.me/adapetamaly', '_blank')}
                      >
                        🔧 Адаптер
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                        onClick={() => window.open('https://t.me/attackamalya', '_blank')}
                      >
                        📢 Канал
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Шёпот */}
                <Card className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border-blue-500/30">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <Avatar className="w-16 h-16 border-2 border-blue-400">
                        <AvatarFallback className="bg-gradient-to-br from-blue-500 to-cyan-500 text-white font-bold">
                          Ш
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-xl font-bold text-white">Шёпот</h3>
                        <p className="text-blue-200">Помощник в проекте</p>
                        <p className="text-sm text-blue-300">Специалист OSINT, программист, дизайнер</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                        onClick={() => window.open('https://t.me/oxaul', '_blank')}
                      >
                        <MessageCircle className="w-4 h-4 mr-2" />
                        @oxaul
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                        onClick={() => window.open('https://t.me/adp_oxaul', '_blank')}
                      >
                        🔧 Адаптер
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                        onClick={() => window.open('https://t.me/+xx4qh91uyS0xN2U0', '_blank')}
                      >
                        📢 Канал
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Skills */}
        <Card className="card-glow">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-gradient">
              <Brain className="w-6 h-6" />
              Экспертиза и навыки
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {author.skills?.map((skill, index) => (
                <Badge 
                  key={index} 
                  className="bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700 transition-all duration-300"
                  data-testid={`skill-${index}`}
                >
                  {skill}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Achievements */}
        <Card className="card-glow">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-gradient">
              <Trophy className="w-6 h-6" />
              Достижения
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {author.achievements?.map((achievement, index) => (
                <div 
                  key={index} 
                  className="flex items-start gap-3 p-3 rounded-lg bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/20"
                  data-testid={`achievement-${index}`}
                >
                  <Star className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                  <p className="text-sm leading-relaxed">{achievement}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Platform Stats */}
      <Card className="card-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-gradient">
            <Target className="w-6 h-6" />
            О платформе "Крис"
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center p-4 rounded-lg bg-gradient-to-br from-purple-500/20 to-purple-600/20 border border-purple-500/30">
              <Shield className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <h3 className="font-semibold text-lg">Безопасность</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Этичный подход к OSINT
              </p>
            </div>

            <div className="text-center p-4 rounded-lg bg-gradient-to-br from-blue-500/20 to-blue-600/20 border border-blue-500/30">
              <Brain className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <h3 className="font-semibold text-lg">ИИ Интеграция</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Grok и DeepSeek модели
              </p>
            </div>

            <div className="text-center p-4 rounded-lg bg-gradient-to-br from-green-500/20 to-green-600/20 border border-green-500/30">
              <Code className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <h3 className="font-semibold text-lg">Технологии</h3>
              <p className="text-sm text-muted-foreground mt-1">
                React, TypeScript, Node.js
              </p>
            </div>

            <div className="text-center p-4 rounded-lg bg-gradient-to-br from-yellow-500/20 to-yellow-600/20 border border-yellow-500/30">
              <Award className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <h3 className="font-semibold text-lg">Качество</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Профессиональный уровень
              </p>
            </div>
          </div>

          <div className="mt-6 p-6 rounded-lg bg-gradient-to-r from-gray-800 to-gray-900 border border-gray-700">
            <h4 className="text-lg font-semibold mb-3 text-gradient">Цель проекта</h4>
            <p className="text-muted-foreground leading-relaxed">
              Платформа "Крис" создана для предоставления легального доступа к инструментам OSINT (Open Source Intelligence) 
              с интеграцией передовых технологий искусственного интеллекта. Мы стремимся к созданию безопасной, 
              этичной и мощной среды для проведения расследований и анализа открытых источников информации.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Contact CTA */}
      <Card className="gradient-bg rainbow-border">
        <CardContent className="p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">
            Сотрудничество и консультации
          </h3>
          <p className="text-white/90 mb-6 max-w-2xl mx-auto">
            Заинтересованы в OSINT консультациях, разработке специализированных инструментов 
            или обучении? Свяжитесь со мной для обсуждения возможностей сотрудничества.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-white text-purple-600 hover:bg-gray-100"
              onClick={() => window.open(`mailto:${author.socialLinks && typeof author.socialLinks === 'object' && 'email' in author.socialLinks ? String(author.socialLinks.email) : ''}`, '_blank')}
              data-testid="button-contact"
            >
              <Mail className="w-5 h-5 mr-2" />
              Связаться
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white/10"
              onClick={() => window.open(`https://t.me/${author.socialLinks && typeof author.socialLinks === 'object' && 'telegram' in author.socialLinks ? String(author.socialLinks.telegram).replace('@', '') : ''}`, '_blank')}
              data-testid="button-telegram-contact"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Telegram
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}