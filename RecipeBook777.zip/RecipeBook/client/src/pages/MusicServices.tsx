import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Music, 
  Play, 
  Pause, 
  Volume2, 
  Heart, 
  Search,
  ExternalLink,
  Shuffle,
  Repeat,
  SkipBack,
  SkipForward,
  Speaker,
  ArrowLeft
} from 'lucide-react';

const musicServices = [
  {
    id: 'spotify',
    name: 'Spotify',
    url: 'https://open.spotify.com',
    color: 'bg-green-500',
    description: 'Миллионы треков и подкастов',
    features: ['Премиум качество', 'Оффлайн режим', 'Плейлисты'],
    logo: '🎵'
  },
  {
    id: 'yandex',
    name: 'Яндекс Музыка',
    url: 'https://music.yandex.ru',
    color: 'bg-red-500',
    description: 'Русская и зарубежная музыка',
    features: ['Умные рекомендации', 'Радио', 'Подкасты'],
    logo: '🎶'
  },
  {
    id: 'youtube',
    name: 'YouTube Music',
    url: 'https://music.youtube.com',
    color: 'bg-red-600',
    description: 'Музыка и клипы на YouTube',
    features: ['Видеоклипы', 'Лайвы', 'Ремиксы'],
    logo: '🎸'
  },
  {
    id: 'apple',
    name: 'Apple Music',
    url: 'https://music.apple.com',
    color: 'bg-gray-800',
    description: 'Музыка от Apple',
    features: ['Hi-Fi качество', 'Эксклюзивы', 'Радио'],
    logo: '🍎'
  },
  {
    id: 'soundcloud',
    name: 'SoundCloud',
    url: 'https://soundcloud.com',
    color: 'bg-orange-500',
    description: 'Независимые артисты',
    features: ['Новые артисты', 'Подкасты', 'Ремиксы'],
    logo: '☁️'
  },
  {
    id: 'deezer',
    name: 'Deezer',
    url: 'https://deezer.com',
    color: 'bg-purple-600',
    description: 'Мировая музыка',
    features: ['FLAC качество', 'Flow', 'Тексты песен'],
    logo: '🎤'
  }
];

export default function MusicServices() {
  const [currentService, setCurrentService] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState('Выберите музыкальный сервис');
  const [searchQuery, setSearchQuery] = useState('');
  const [showIframe, setShowIframe] = useState(false);
  const [iframeUrl, setIframeUrl] = useState('');

  const handleServiceClick = (service: any) => {
    setCurrentService(service.id);
    setCurrentTrack(`Подключение к ${service.name}...`);
    setIframeUrl(service.url);
    setShowIframe(true);
  };

  const closeIframe = () => {
    setShowIframe(false);
    setIframeUrl('');
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  if (showIframe) {
    return (
      <div className="h-full flex flex-col">
        {/* Iframe Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-card">
          <div className="flex items-center gap-3">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={closeIframe}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Назад
            </Button>
            <div className="flex items-center gap-2">
              <Music className="w-5 h-5 text-purple-400" />
              <span className="font-medium">{musicServices.find(s => s.id === currentService)?.name}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => window.open(iframeUrl, '_blank')}
              className="flex items-center gap-2"
            >
              <ExternalLink className="w-4 h-4" />
              Открыть в браузере
            </Button>
          </div>
        </div>
        
        {/* Iframe */}
        <div className="flex-1">
          <iframe 
            src={iframeUrl}
            className="w-full h-full border-0"
            title={`${musicServices.find(s => s.id === currentService)?.name} Player`}
            allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
            sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-top-navigation"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header with animated background */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 via-blue-500/20 to-pink-500/20 rounded-lg blur-xl"></div>
        <Card className="relative rainbow-border gradient-bg">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
                  <Music className="w-10 h-10 floating" />
                  Музыкальные сервисы
                </h1>
                <p className="text-white/80 text-lg">
                  Слушайте любимую музыку во время работы с OSINT
                </p>
              </div>
              <div className="text-6xl floating">🎵</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Music Player Interface */}
      <Card className="card-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Speaker className="w-6 h-6 text-purple-400" />
            Плеер
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Now Playing */}
          <div className="bg-gradient-to-r from-gray-800 to-gray-900 p-4 rounded-lg">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                <Music className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-white">{currentTrack}</h3>
                <p className="text-gray-400">{currentService ? musicServices.find(s => s.id === currentService)?.name : 'Не выбран'}</p>
              </div>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                  <Heart className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4">
            <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
              <Shuffle className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
              <SkipBack className="w-4 h-4" />
            </Button>
            <Button 
              size="lg"
              className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              onClick={togglePlay}
            >
              {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
            </Button>
            <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
              <SkipForward className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
              <Repeat className="w-4 h-4" />
            </Button>
          </div>

          {/* Volume */}
          <div className="flex items-center gap-4">
            <Volume2 className="w-4 h-4 text-gray-400" />
            <div className="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
              <div className="w-2/3 h-full bg-gradient-to-r from-purple-500 to-blue-500"></div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search */}
      <Card className="card-glow">
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Поиск музыки, артистов, альбомов..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-gray-800 border-gray-600 text-white"
                data-testid="input-music-search"
              />
            </div>
            <Button className="bg-gradient-to-r from-purple-600 to-blue-600">
              <Search className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Music Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {musicServices.map((service) => (
          <Card 
            key={service.id} 
            className={`card-glow hover:scale-105 transition-all duration-300 cursor-pointer group ${
              currentService === service.id ? 'ring-2 ring-purple-500' : ''
            }`}
            onClick={() => handleServiceClick(service)}
            data-testid={`service-${service.id}`}
          >
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 ${service.color} rounded-lg flex items-center justify-center text-2xl group-hover:scale-110 transition-transform`}>
                    {service.logo}
                  </div>
                  <div>
                    <CardTitle className="text-lg group-hover:text-gradient transition-all">
                      {service.name}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {service.description}
                    </p>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-white transition-colors" />
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-1">
                {service.features.map((feature, index) => (
                  <Badge 
                    key={index} 
                    variant="secondary" 
                    className="text-xs bg-gradient-to-r from-purple-500/20 to-blue-500/20 text-purple-200 border-purple-500/30"
                  >
                    {feature}
                  </Badge>
                ))}
              </div>

              <Button 
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                onClick={(e) => {
                  e.stopPropagation();
                  handleServiceClick(service);
                }}
                data-testid={`button-open-${service.id}`}
              >
                <Play className="w-4 h-4 mr-2" />
                Открыть {service.name}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Music Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="card-glow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Music className="w-5 h-5 text-purple-400" />
              <div>
                <p className="text-sm text-muted-foreground">Сервисов</p>
                <p className="text-2xl font-bold text-gradient">{musicServices.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-glow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Heart className="w-5 h-5 text-pink-400" />
              <div>
                <p className="text-sm text-muted-foreground">Избранное</p>
                <p className="text-2xl font-bold text-gradient">0</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-glow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Volume2 className="w-5 h-5 text-blue-400" />
              <div>
                <p className="text-sm text-muted-foreground">Громкость</p>
                <p className="text-2xl font-bold text-gradient">67%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-glow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Play className="w-5 h-5 text-green-400" />
              <div>
                <p className="text-sm text-muted-foreground">Статус</p>
                <p className="text-2xl font-bold text-gradient">{isPlaying ? 'Играет' : 'Пауза'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pro Tip */}
      <Card className="gradient-bg rainbow-border">
        <CardContent className="p-6 text-center">
          <h3 className="text-xl font-bold text-white mb-2">💡 Совет</h3>
          <p className="text-white/90">
            Музыка помогает концентрироваться во время OSINT исследований. 
            Выберите спокойные треки или фоновую музыку для лучшей продуктивности.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}