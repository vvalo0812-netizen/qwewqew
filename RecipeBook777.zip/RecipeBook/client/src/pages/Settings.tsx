import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Settings as SettingsIcon, 
  Key, 
  Users, 
  Bell, 
  Shield, 
  Palette, 
  Database,
  Globe,
  MessageSquare,
  Code,
  Save,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';

interface DevChatMessage {
  id: string;
  message: string;
  timestamp: Date;
  isFromDev: boolean;
}

export default function Settings() {
  const [devKey, setDevKey] = useState('');
  const [isDevAuthenticated, setIsDevAuthenticated] = useState(false);
  const [devMessage, setDevMessage] = useState('');
  const [devChatMessages, setDevChatMessages] = useState<DevChatMessage[]>([
    {
      id: '1',
      message: 'Добро пожаловать в чат разработчиков! Здесь мы делимся важными обновлениями и получаем фидбек.',
      timestamp: new Date(Date.now() - 3600000),
      isFromDev: true
    },
    {
      id: '2', 
      message: 'Система работает стабильно. Если есть вопросы - пишите!',
      timestamp: new Date(Date.now() - 1800000),
      isFromDev: true
    }
  ]);

  // Settings state
  const [notifications, setNotifications] = useState(true);
  const [autoUpdates, setAutoUpdates] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [apiKeys, setApiKeys] = useState({
    grok: '',
    deepseek: '',
    openai: ''
  });

  const DEV_KEY = 'qwertyasdfghzxcvbzxczxc';

  const authenticateDevKey = () => {
    if (devKey === DEV_KEY) {
      setIsDevAuthenticated(true);
      setDevKey('');
    } else {
      alert('Неверный ключ разработчика');
    }
  };

  const sendDevMessage = () => {
    if (!devMessage.trim() || !isDevAuthenticated) return;

    const newMessage: DevChatMessage = {
      id: Date.now().toString(),
      message: devMessage,
      timestamp: new Date(),
      isFromDev: false
    };

    setDevChatMessages(prev => [...prev, newMessage]);
    setDevMessage('');

    // Simulate auto-response from dev
    setTimeout(() => {
      const autoResponse: DevChatMessage = {
        id: (Date.now() + 1).toString(),
        message: 'Сообщение получено! Спасибо за обратную связь. Команда разработчиков рассмотрит ваше сообщение.',
        timestamp: new Date(),
        isFromDev: true
      };
      setDevChatMessages(prev => [...prev, autoResponse]);
    }, 2000);
  };

  const saveSettings = () => {
    // Save settings to localStorage or API
    localStorage.setItem('sora_settings', JSON.stringify({
      notifications,
      autoUpdates,
      darkMode,
      apiKeys
    }));
    alert('Настройки сохранены!');
  };

  const resetSettings = () => {
    setNotifications(true);
    setAutoUpdates(true);
    setDarkMode(true);
    setApiKeys({ grok: '', deepseek: '', openai: '' });
    localStorage.removeItem('sora_settings');
    alert('Настройки сброшены!');
  };

  return (
    <div className="h-full overflow-auto p-6 space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-gray-500 to-slate-600 rounded-lg flex items-center justify-center">
            <SettingsIcon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gradient">Настройки</h1>
            <p className="text-muted-foreground">Конфигурация системы и персонализация</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general" className="flex items-center gap-2">
            <SettingsIcon className="w-4 h-4" />
            Общие
          </TabsTrigger>
          <TabsTrigger value="api" className="flex items-center gap-2">
            <Key className="w-4 h-4" />
            API ключи
          </TabsTrigger>
          <TabsTrigger value="dev-chat" className="flex items-center gap-2">
            <Code className="w-4 h-4" />
            Dev чат
          </TabsTrigger>
          <TabsTrigger value="about" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            О системе
          </TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Уведомления и интерфейс
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium">Уведомления</h4>
                  <p className="text-sm text-muted-foreground">Получать уведомления о завершении анализа</p>
                </div>
                <Switch checked={notifications} onCheckedChange={setNotifications} />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium">Автообновления</h4>
                  <p className="text-sm text-muted-foreground">Автоматически обновлять приложение</p>
                </div>
                <Switch checked={autoUpdates} onCheckedChange={setAutoUpdates} />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium">Темная тема</h4>
                  <p className="text-sm text-muted-foreground">Использовать темную тему интерфейса</p>
                </div>
                <Switch checked={darkMode} onCheckedChange={setDarkMode} />
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-4">
            <Button onClick={saveSettings} className="flex items-center gap-2">
              <Save className="w-4 h-4" />
              Сохранить
            </Button>
            <Button variant="outline" onClick={resetSettings} className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4" />
              Сбросить
            </Button>
          </div>
        </TabsContent>

        {/* API Keys */}
        <TabsContent value="api" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="w-5 h-5" />
                API ключи для ИИ моделей
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">xAI Grok API Key</label>
                <Input
                  type="password"
                  placeholder="Введите ключ API для Grok..."
                  value={apiKeys.grok}
                  onChange={(e) => setApiKeys(prev => ({ ...prev, grok: e.target.value }))}
                />
                <p className="text-xs text-muted-foreground">
                  Получите ключ на <a href="https://x.ai" target="_blank" className="text-blue-500 hover:underline">x.ai</a>
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">DeepSeek API Key</label>
                <Input
                  type="password"
                  placeholder="Введите ключ API для DeepSeek..."
                  value={apiKeys.deepseek}
                  onChange={(e) => setApiKeys(prev => ({ ...prev, deepseek: e.target.value }))}
                />
                <p className="text-xs text-muted-foreground">
                  Получите ключ на <a href="https://platform.deepseek.com" target="_blank" className="text-blue-500 hover:underline">platform.deepseek.com</a>
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">OpenAI API Key (опционально)</label>
                <Input
                  type="password"
                  placeholder="Введите ключ API для OpenAI..."
                  value={apiKeys.openai}
                  onChange={(e) => setApiKeys(prev => ({ ...prev, openai: e.target.value }))}
                />
                <p className="text-xs text-muted-foreground">
                  Получите ключ на <a href="https://platform.openai.com" target="_blank" className="text-blue-500 hover:underline">platform.openai.com</a>
                </p>
              </div>

              <div className="bg-muted p-4 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-500 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium">Безопасность</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      API ключи хранятся локально в зашифрованном виде. Они используются только для прямого обращения к AI сервисам.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Developer Chat */}
        <TabsContent value="dev-chat" className="space-y-6">
          {!isDevAuthenticated ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  Доступ к чату разработчиков
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Введите ключ разработчика для доступа к закрытому чату с командой разработки
                </p>
                <div className="flex gap-4">
                  <Input
                    type="password"
                    placeholder="Ключ разработчика..."
                    value={devKey}
                    onChange={(e) => setDevKey(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && authenticateDevKey()}
                  />
                  <Button onClick={authenticateDevKey}>
                    Войти
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  Чат с разработчиками
                  <Badge variant="outline" className="bg-green-100 text-green-800">
                    Активен
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Messages */}
                <div className="h-64 overflow-y-auto space-y-3 border rounded-lg p-4 bg-muted/30">
                  {devChatMessages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.isFromDev ? 'justify-start' : 'justify-end'}`}>
                      <div className={`max-w-[70%] rounded-lg p-3 ${
                        msg.isFromDev 
                          ? 'bg-blue-500 text-white' 
                          : 'bg-white border'
                      }`}>
                        <p className="text-sm">{msg.message}</p>
                        <p className={`text-xs mt-1 ${
                          msg.isFromDev ? 'text-blue-100' : 'text-muted-foreground'
                        }`}>
                          {msg.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Send Message */}
                <div className="flex gap-2">
                  <Textarea
                    placeholder="Напишите сообщение разработчикам..."
                    value={devMessage}
                    onChange={(e) => setDevMessage(e.target.value)}
                    rows={2}
                    className="flex-1"
                  />
                  <Button onClick={sendDevMessage} disabled={!devMessage.trim()}>
                    Отправить
                  </Button>
                </div>

                <p className="text-xs text-muted-foreground">
                  Ваши сообщения отправляются напрямую команде разработчиков. Мы отвечаем в течение 24 часов.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* About System */}
        <TabsContent value="about" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                О системе Sora
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Версия</h4>
                  <p className="text-lg font-semibold">2.1.0</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Билд</h4>
                  <p className="text-lg font-semibold">#2024.12.21</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Архитектура</h4>
                  <p className="text-lg font-semibold">Electron + React</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Платформа</h4>
                  <p className="text-lg font-semibold">Windows x64</p>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="text-sm font-medium mb-2">Компоненты системы</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">OSINT Framework</span>
                    <Badge variant="outline" className="bg-green-100 text-green-800">Активен</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">AI Chat (Grok + DeepSeek)</span>
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Настройка</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Terminal</span>
                    <Badge variant="outline" className="bg-green-100 text-green-800">Активен</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">File Manager</span>
                    <Badge variant="outline" className="bg-green-100 text-green-800">Активен</Badge>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="text-sm font-medium mb-2">Права и лицензии</h4>
                <p className="text-sm text-muted-foreground">
                  © 2024 Sora OSINT Platform. Разработано командой Amalya & Шёпот.
                  Все права защищены. Использование в коммерческих целях запрещено.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}