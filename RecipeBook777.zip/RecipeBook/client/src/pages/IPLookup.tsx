import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  MapPin, 
  Search, 
  Globe, 
  Building, 
  Shield, 
  Wifi, 
  Clock,
  AlertTriangle,
  ExternalLink,
  Copy
} from 'lucide-react';

interface IPInfo {
  ip: string;
  city: string;
  region: string;
  country: string;
  loc: string;
  org: string;
  postal: string;
  timezone: string;
  hostname?: string;
  asn?: string;
  company?: string;
  privacy?: {
    vpn: boolean;
    proxy: boolean;
    tor: boolean;
    relay: boolean;
    hosting: boolean;
    service: string;
  };
}

export default function IPLookup() {
  const [ipAddress, setIpAddress] = useState('');
  const [ipInfo, setIpInfo] = useState<IPInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const validateIP = (ip: string) => {
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const ipv6Regex = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
    return ipv4Regex.test(ip) || ipv6Regex.test(ip);
  };

  const lookupIP = async () => {
    if (!ipAddress.trim()) {
      setError('Введите IP адрес');
      return;
    }

    if (!validateIP(ipAddress.trim())) {
      setError('Неверный формат IP адреса');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      // Используем бесплатный API ipinfo.io
      const response = await fetch(`https://ipinfo.io/${ipAddress.trim()}/json`);
      
      if (!response.ok) {
        throw new Error('Ошибка при получении данных');
      }
      
      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error.message || 'Не удалось получить информацию об IP');
      }

      // Дополнительная проверка через API для VPN/Proxy
      try {
        const vpnResponse = await fetch(`https://ipapi.co/${ipAddress.trim()}/json/`);
        const vpnData = await vpnResponse.json();
        
        if (vpnData && !vpnData.error) {
          data.privacy = {
            vpn: vpnData.threat_types?.includes('vpn') || false,
            proxy: vpnData.threat_types?.includes('proxy') || false,
            tor: vpnData.threat_types?.includes('tor') || false,
            relay: vpnData.threat_types?.includes('relay') || false,
            hosting: vpnData.connection_type === 'hosting' || false,
            service: vpnData.connection_type || 'unknown'
          };
          data.asn = vpnData.asn;
          data.company = vpnData.org;
        }
      } catch (vpnError) {
        console.log('VPN check failed:', vpnError);
      }

      setIpInfo(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const openGoogleMaps = () => {
    if (ipInfo?.loc) {
      const [lat, lng] = ipInfo.loc.split(',');
      window.open(`https://maps.google.com?q=${lat},${lng}`, '_blank');
    }
  };

  const getRiskLevel = (info: IPInfo) => {
    if (info.privacy?.vpn || info.privacy?.proxy || info.privacy?.tor) {
      return { level: 'high', label: 'Высокий', color: 'bg-red-100 text-red-800 border-red-200' };
    }
    if (info.privacy?.hosting || info.privacy?.relay) {
      return { level: 'medium', label: 'Средний', color: 'bg-yellow-100 text-yellow-800 border-yellow-200' };
    }
    return { level: 'low', label: 'Низкий', color: 'bg-green-100 text-green-800 border-green-200' };
  };

  return (
    <div className="h-full overflow-auto p-6 space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
            <MapPin className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gradient">IP Lookup</h1>
            <p className="text-muted-foreground">Геолокация и анализ IP адресов</p>
          </div>
        </div>

        {/* Search Form */}
        <Card>
          <CardContent className="p-6">
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Введите IP адрес (например: 8.8.8.8)"
                  value={ipAddress}
                  onChange={(e) => setIpAddress(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && lookupIP()}
                />
                {error && (
                  <p className="text-sm text-red-500 mt-2">{error}</p>
                )}
              </div>
              <Button 
                onClick={lookupIP}
                disabled={loading}
                className="min-w-[120px]"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Поиск...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Найти
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent className="space-y-4">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent className="space-y-4">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </CardContent>
          </Card>
        </div>
      )}

      {/* Results */}
      {ipInfo && !loading && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Main Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Основная информация
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">IP адрес:</span>
                <div className="flex items-center gap-2">
                  <code className="bg-muted px-2 py-1 rounded text-sm">{ipInfo.ip}</code>
                  <Button 
                    size="sm" 
                    variant="ghost"
                    onClick={() => copyToClipboard(ipInfo.ip)}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {ipInfo.hostname && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Hostname:</span>
                  <span className="text-sm font-mono">{ipInfo.hostname}</span>
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Провайдер:</span>
                <span className="text-sm">{ipInfo.org || ipInfo.company || 'Неизвестно'}</span>
              </div>

              {ipInfo.asn && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">ASN:</span>
                  <span className="text-sm font-mono">{ipInfo.asn}</span>
                </div>
              )}

              {ipInfo.timezone && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Часовой пояс:</span>
                  <span className="text-sm">{ipInfo.timezone}</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Location */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Геолокация
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Страна:</span>
                <span className="text-sm">{ipInfo.country || 'Неизвестно'}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Регион:</span>
                <span className="text-sm">{ipInfo.region || 'Неизвестно'}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Город:</span>
                <span className="text-sm">{ipInfo.city || 'Неизвестно'}</span>
              </div>

              {ipInfo.postal && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Почтовый код:</span>
                  <span className="text-sm">{ipInfo.postal}</span>
                </div>
              )}

              {ipInfo.loc && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Координаты:</span>
                    <span className="text-sm font-mono">{ipInfo.loc}</span>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={openGoogleMaps}
                    className="w-full"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Открыть на карте
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Security Analysis */}
          {ipInfo.privacy && (
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Анализ безопасности
                  <Badge variant="outline" className={getRiskLevel(ipInfo).color}>
                    Риск: {getRiskLevel(ipInfo).label}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <div className="text-center">
                    <div className={`w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center ${
                      ipInfo.privacy.vpn ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
                    }`}>
                      <Wifi className="w-4 h-4" />
                    </div>
                    <p className="text-xs text-muted-foreground">VPN</p>
                    <p className="text-sm font-medium">{ipInfo.privacy.vpn ? 'Да' : 'Нет'}</p>
                  </div>

                  <div className="text-center">
                    <div className={`w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center ${
                      ipInfo.privacy.proxy ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
                    }`}>
                      <Globe className="w-4 h-4" />
                    </div>
                    <p className="text-xs text-muted-foreground">Proxy</p>
                    <p className="text-sm font-medium">{ipInfo.privacy.proxy ? 'Да' : 'Нет'}</p>
                  </div>

                  <div className="text-center">
                    <div className={`w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center ${
                      ipInfo.privacy.tor ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
                    }`}>
                      <Shield className="w-4 h-4" />
                    </div>
                    <p className="text-xs text-muted-foreground">Tor</p>
                    <p className="text-sm font-medium">{ipInfo.privacy.tor ? 'Да' : 'Нет'}</p>
                  </div>

                  <div className="text-center">
                    <div className={`w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center ${
                      ipInfo.privacy.hosting ? 'bg-yellow-100 text-yellow-600' : 'bg-green-100 text-green-600'
                    }`}>
                      <Building className="w-4 h-4" />
                    </div>
                    <p className="text-xs text-muted-foreground">Хостинг</p>
                    <p className="text-sm font-medium">{ipInfo.privacy.hosting ? 'Да' : 'Нет'}</p>
                  </div>

                  <div className="text-center">
                    <div className="w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center bg-blue-100 text-blue-600">
                      <Wifi className="w-4 h-4" />
                    </div>
                    <p className="text-xs text-muted-foreground">Тип подключения</p>
                    <p className="text-sm font-medium">{ipInfo.privacy.service}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* No Results */}
      {!ipInfo && !loading && (
        <div className="text-center py-12">
          <MapPin className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Введите IP адрес</h3>
          <p className="text-muted-foreground">
            Введите IPv4 или IPv6 адрес для получения информации о геолокации и провайдере
          </p>
        </div>
      )}
    </div>
  );
}