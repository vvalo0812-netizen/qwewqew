import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Search, Database, FileText, AlertCircle, CheckCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface SearchResult {
  path: string;
  data: any;
  type: string;
  found: boolean;
  timestamp: string;
}

export default function DatabaseSearch() {
  const [searchPath, setSearchPath] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);

  const searchMutation = useMutation({
    mutationFn: async (path: string): Promise<SearchResult> => {
      const response = await fetch("/api/database/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path }),
      });
      
      if (!response.ok) {
        throw new Error(`Ошибка поиска: ${response.statusText}`);
      }
      
      return response.json();
    },
    onSuccess: (result) => {
      setResults(prev => [result, ...prev]);
    },
  });

  const handleSearch = () => {
    if (!searchPath.trim()) return;
    searchMutation.mutate(searchPath);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSearch();
    }
  };

  const clearResults = () => {
    setResults([]);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Database className="h-8 w-8 text-purple-500" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">
            Поиск по Базе Данных
          </h1>
        </div>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Введите путь для поиска информации в базе данных. Поддерживаются различные форматы путей и ключей.
        </p>
      </div>

      <Card className="bg-gray-900/50 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5 text-purple-500" />
            Поиск по Пути
          </CardTitle>
          <CardDescription>
            Введите путь к данным в формате: table.field, user.id, analysis.phone_number
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={searchPath}
              onChange={(e) => setSearchPath(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Например: users.phone, analysis.results, osint.data"
              className="flex-1 bg-gray-800 border-gray-600 text-white"
              disabled={searchMutation.isPending}
            />
            <Button
              onClick={handleSearch}
              disabled={!searchPath.trim() || searchMutation.isPending}
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
            >
              {searchMutation.isPending ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
              ) : (
                <Search className="h-4 w-4" />
              )}
              Поиск
            </Button>
          </div>
          
          {results.length > 0 && (
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">
                Найдено результатов: {results.length}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={clearResults}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Очистить
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {searchMutation.error && (
        <Alert className="border-red-500 bg-red-900/20">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-red-300">
            {searchMutation.error.message}
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-4">
        {results.map((result, index) => (
          <Card key={index} className="bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-blue-500" />
                  <span className="text-lg">{result.path}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={result.found ? "default" : "destructive"} className="text-xs">
                    {result.found ? (
                      <>
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Найдено
                      </>
                    ) : (
                      <>
                        <AlertCircle className="h-3 w-3 mr-1" />
                        Не найдено
                      </>
                    )}
                  </Badge>
                  <Badge variant="outline" className="text-xs text-gray-400">
                    {result.type}
                  </Badge>
                </div>
              </CardTitle>
              <CardDescription className="text-xs text-gray-500">
                {new Date(result.timestamp).toLocaleString('ru-RU')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-800 rounded-lg p-4">
                <h4 className="text-sm font-medium text-gray-300 mb-2">Результат:</h4>
                <Textarea
                  value={typeof result.data === 'string' ? result.data : JSON.stringify(result.data, null, 2)}
                  readOnly
                  className="min-h-[100px] font-mono text-sm bg-gray-900 border-gray-600 text-gray-200"
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {results.length === 0 && !searchMutation.isPending && (
        <Card className="bg-gray-900/30 border-gray-700 border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Database className="h-12 w-12 text-gray-500 mb-4" />
            <h3 className="text-lg font-medium text-gray-400 mb-2">
              Результаты поиска появятся здесь
            </h3>
            <p className="text-sm text-gray-500 max-w-md">
              Введите путь к данным и нажмите "Поиск" для начала поиска по базе данных
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}