import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, 
  Eye, 
  Copy, 
  ExternalLink, 
  Bot,
  FileText,
  Database,
  Lock,
  Globe,
  Shield,
  AlertTriangle,
  Book,
  Target,
  Zap
} from 'lucide-react';

interface GoogleDork {
  name: string;
  query: string;
  description: string;
  category: string;
  risk: 'low' | 'medium' | 'high';
  example?: string;
}

const googleDorks: GoogleDork[] = [
  // Файлы и документы
  { name: 'PDF файлы', query: 'filetype:pdf', description: 'Поиск PDF документов', category: 'files', risk: 'low', example: 'filetype:pdf "confidential"' },
  { name: 'Excel файлы', query: 'filetype:xls OR filetype:xlsx', description: 'Поиск Excel документов', category: 'files', risk: 'low' },
  { name: 'Word документы', query: 'filetype:doc OR filetype:docx', description: 'Поиск Word документов', category: 'files', risk: 'low' },
  { name: 'PowerPoint', query: 'filetype:ppt OR filetype:pptx', description: 'Поиск презентаций', category: 'files', risk: 'low' },
  { name: 'SQL файлы', query: 'filetype:sql', description: 'Поиск SQL дампов', category: 'files', risk: 'high', example: 'filetype:sql "password" OR "passwd"' },
  { name: 'Конфиг файлы', query: 'filetype:conf OR filetype:config', description: 'Поиск конфигурационных файлов', category: 'files', risk: 'high' },
  { name: 'Log файлы', query: 'filetype:log', description: 'Поиск лог файлов', category: 'files', risk: 'medium' },
  { name: 'Backup файлы', query: 'filetype:bak OR filetype:backup', description: 'Поиск backup файлов', category: 'files', risk: 'high' },
  
  // Уязвимости
  { name: 'Directory Listing', query: 'intitle:"Index of /"', description: 'Открытые директории', category: 'vulnerabilities', risk: 'medium' },
  { name: 'Apache Status', query: 'intitle:"Apache Status" "Apache Server Status"', description: 'Страницы статуса Apache', category: 'vulnerabilities', risk: 'medium' },
  { name: 'phpMyAdmin', query: 'intitle:"phpMyAdmin" "Welcome to phpMyAdmin"', description: 'Открытые phpMyAdmin панели', category: 'vulnerabilities', risk: 'high' },
  { name: 'PHP Info', query: 'intitle:"phpinfo()" "PHP Version"', description: 'Страницы PHP info', category: 'vulnerabilities', risk: 'medium' },
  { name: 'Server Info', query: 'intitle:"server info" "Apache/2"', description: 'Информация о сервере', category: 'vulnerabilities', risk: 'medium' },
  { name: 'Error Pages', query: 'intitle:"404 not found" | intitle:"500 internal server error"', description: 'Страницы ошибок с информацией', category: 'vulnerabilities', risk: 'low' },
  
  // Логины и пароли
  { name: 'FTP пароли', query: 'filetype:txt "password" | "passwd" | "pwd" ftp', description: 'FTP учетные данные', category: 'credentials', risk: 'high' },
  { name: 'MySQL пароли', query: 'inurl:"/etc/passwd" ext:passwd', description: 'MySQL учетные данные', category: 'credentials', risk: 'high' },
  { name: 'SSH ключи', query: 'filetype:key "BEGIN RSA PRIVATE KEY"', description: 'SSH приватные ключи', category: 'credentials', risk: 'high' },
  { name: 'htpasswd файлы', query: 'filetype:htpasswd htpasswd', description: 'Файлы паролей Apache', category: 'credentials', risk: 'high' },
  { name: 'Конфиги с паролями', query: 'ext:txt | ext:cfg | ext:env "password="', description: 'Конфиги с паролями', category: 'credentials', risk: 'high' },
  
  // Базы данных
  { name: 'SQL дампы', query: 'ext:sql "CREATE TABLE" | "INSERT INTO"', description: 'SQL дампы баз данных', category: 'databases', risk: 'high' },
  { name: 'MongoDB', query: 'intitle:"It looks like you are trying to access MongoDB"', description: 'Открытые MongoDB', category: 'databases', risk: 'high' },
  { name: 'Elasticsearch', query: 'intitle:"Elasticsearch" port:9200', description: 'Открытые Elasticsearch кластеры', category: 'databases', risk: 'high' },
  { name: 'Redis', query: 'port:6379 "redis_version"', description: 'Открытые Redis сервера', category: 'databases', risk: 'high' },
  
  // Камеры и IoT
  { name: 'IP камеры', query: 'intitle:"Live View / - AXIS" | intitle:"Live View"', description: 'IP камеры видеонаблюдения', category: 'iot', risk: 'medium' },
  { name: 'Webcam XP', query: 'intitle:"webcam xp 5"', description: 'Веб-камеры XP', category: 'iot', risk: 'medium' },
  { name: 'Router настройки', query: 'intitle:"DD-WRT" | intitle:"router"', description: 'Интерфейсы роутеров', category: 'iot', risk: 'medium' },
  { name: 'Принтеры', query: 'intitle:"HP LaserJet" | intitle:"printer"', description: 'Сетевые принтеры', category: 'iot', risk: 'low' },
  
  // Социальная инженерия
  { name: 'Email списки', query: 'filetype:xls | filetype:csv "email" | "e-mail"', description: 'Списки email адресов', category: 'social', risk: 'medium' },
  { name: 'Контактные данные', query: 'filetype:doc | filetype:pdf "phone" | "mobile" | "contact"', description: 'Контактная информация', category: 'social', risk: 'low' },
  { name: 'Резюме', query: 'filetype:doc | filetype:pdf "resume" | "CV"', description: 'Резюме сотрудников', category: 'social', risk: 'low' },
  { name: 'Org структура', query: 'filetype:pdf | filetype:doc "org chart" | "organizational"', description: 'Организационные структуры', category: 'social', risk: 'low' },
  
  // Финансы
  { name: 'Инвойсы', query: 'filetype:pdf "invoice" | "bill" | "payment"', description: 'Счета и инвойсы', category: 'financial', risk: 'medium' },
  { name: 'Банковские данные', query: 'filetype:xls "account number" | "routing number"', description: 'Банковская информация', category: 'financial', risk: 'high' },
  { name: 'Paypal', query: 'filetype:log "paypal"', description: 'Логи Paypal транзакций', category: 'financial', risk: 'high' },
  
  // Правительство
  { name: 'Госдокументы', query: 'site:gov filetype:pdf "classified" | "confidential"', description: 'Секретные госдокументы', category: 'government', risk: 'medium' },
  { name: 'Военные документы', query: 'site:mil filetype:pdf', description: 'Военные документы', category: 'government', risk: 'medium' },
  
  // Конкретные сайты
  { name: 'GitHub secrets', query: 'site:github.com "password" | "secret" | "key"', description: 'Секреты в GitHub', category: 'sites', risk: 'high' },
  { name: 'Pastebin утечки', query: 'site:pastebin.com "password" | "leak"', description: 'Утечки в Pastebin', category: 'sites', risk: 'high' },
  { name: 'Trello boards', query: 'site:trello.com "password" | "api"', description: 'Открытые Trello доски', category: 'sites', risk: 'medium' },
];

const categories = [
  { id: 'all', name: 'Все', icon: Search },
  { id: 'files', name: 'Файлы', icon: FileText },
  { id: 'vulnerabilities', name: 'Уязвимости', icon: Shield },
  { id: 'credentials', name: 'Учетные данные', icon: Lock },
  { id: 'databases', name: 'Базы данных', icon: Database },
  { id: 'iot', name: 'IoT устройства', icon: Globe },
  { id: 'social', name: 'Соц. инженерия', icon: Target },
  { id: 'financial', name: 'Финансы', icon: AlertTriangle },
  { id: 'government', name: 'Госсектор', icon: Book },
  { id: 'sites', name: 'Сайты', icon: ExternalLink }
];

const riskColors = {
  low: 'bg-green-100 text-green-800 border-green-200',
  medium: 'bg-yellow-100 text-yellow-800 border-yellow-200', 
  high: 'bg-red-100 text-red-800 border-red-200'
};

const riskLabels = {
  low: 'Низкий',
  medium: 'Средний',
  high: 'Высокий'
};

export default function GoogleDorks() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [customQuery, setCustomQuery] = useState('');
  const [aiHelp, setAiHelp] = useState('');

  const filteredDorks = googleDorks.filter(dork => {
    const matchesCategory = activeCategory === 'all' || dork.category === activeCategory;
    const matchesSearch = dork.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         dork.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         dork.query.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const searchGoogle = (query: string) => {
    const encodedQuery = encodeURIComponent(query);
    window.open(`https://google.com/search?q=${encodedQuery}`, '_blank');
  };

  const generateAIDork = async () => {
    if (!aiHelp.trim()) return;
    
    // Здесь можно интегрировать с AI API для генерации дорков
    const exampleResponse = `Для поиска "${aiHelp}" рекомендую следующие дорки:

1. site:target.com filetype:pdf "${aiHelp}"
2. intitle:"${aiHelp}" -site:example.com
3. "${aiHelp}" filetype:doc OR filetype:xls
4. inurl:"${aiHelp}" -advertisement`;
    
    setCustomQuery(exampleResponse);
  };

  return (
    <div className="h-full overflow-auto p-6 space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
            <Eye className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gradient">Google Dorks</h1>
            <p className="text-muted-foreground">Специальные поисковые запросы для Google OSINT</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Поиск дорков..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <Tabs value={activeCategory} onValueChange={setActiveCategory} className="space-y-6">
        <TabsList className="flex flex-wrap h-auto p-1 gap-1">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <TabsTrigger 
                key={category.id} 
                value={category.id}
                className="flex items-center gap-2 px-3 py-2"
              >
                <Icon className="w-4 h-4" />
                {category.name}
              </TabsTrigger>
            );
          })}
        </TabsList>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* AI Helper */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="w-5 h-5" />
                  ИИ Помощник
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Опишите что нужно найти, и ИИ предложит подходящие дорки..."
                  value={aiHelp}
                  onChange={(e) => setAiHelp(e.target.value)}
                  rows={3}
                />
                <Button 
                  onClick={generateAIDork}
                  className="w-full"
                  disabled={!aiHelp.trim()}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Сгенерировать дорки
                </Button>
                
                {customQuery && (
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Предложения ИИ:</h4>
                    <div className="bg-muted p-3 rounded-md text-sm whitespace-pre-wrap">
                      {customQuery}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Dorks List */}
          <div className="lg:col-span-2">
            <TabsContent value={activeCategory} className="space-y-4 mt-0">
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>Найдено: {filteredDorks.length} дорков</span>
                <Badge variant="outline">{googleDorks.length} всего</Badge>
              </div>

              <div className="space-y-3">
                {filteredDorks.map((dork, index) => (
                  <Card key={index} className="group hover:shadow-md transition-all duration-200">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-medium">{dork.name}</h3>
                            <Badge 
                              variant="outline" 
                              className={`text-xs ${riskColors[dork.risk]}`}
                            >
                              {riskLabels[dork.risk]} риск
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {dork.description}
                          </p>
                        </div>
                      </div>

                      <div className="bg-muted p-3 rounded-md mb-3">
                        <code className="text-sm font-mono">{dork.query}</code>
                      </div>

                      {dork.example && (
                        <div className="mb-3">
                          <p className="text-xs text-muted-foreground mb-1">Пример:</p>
                          <div className="bg-muted/50 p-2 rounded text-xs">
                            <code>{dork.example}</code>
                          </div>
                        </div>
                      )}

                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => copyToClipboard(dork.query)}
                        >
                          <Copy className="w-4 h-4 mr-1" />
                          Копировать
                        </Button>
                        <Button 
                          size="sm"
                          onClick={() => searchGoogle(dork.query)}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Поиск в Google
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {filteredDorks.length === 0 && (
                <div className="text-center py-12">
                  <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Ничего не найдено</h3>
                  <p className="text-muted-foreground">
                    Попробуйте изменить поисковый запрос или выбрать другую категорию
                  </p>
                </div>
              )}
            </TabsContent>
          </div>
        </div>
      </Tabs>
    </div>
  );
}