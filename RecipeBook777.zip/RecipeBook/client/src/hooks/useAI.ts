import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export function useAI() {
  const [isLoading, setIsLoading] = useState(false);

  const { data: providers = [] } = useQuery({
    queryKey: ['/api/ai/providers'],
  });

  const sendMessage = async (provider: string, messages: any[], model?: string) => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/ai/chat', {
        provider,
        messages,
        model
      });
      const data = await response.json();
      return data.response;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    sendMessage,
    isLoading,
    providers
  };
}
