import { useState, useEffect, useRef } from 'react';

export function useTerminal() {
  const [output, setOutput] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const connect = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}`);
      
      ws.onopen = () => {
        setIsConnected(true);
        wsRef.current = ws;
      };

      ws.onmessage = (event) => {
        const message = JSON.parse(event.data);
        if (message.type === 'output') {
          setOutput(prev => prev + message.data);
        }
      };

      ws.onclose = () => {
        setIsConnected(false);
        wsRef.current = null;
        // Attempt to reconnect after 3 seconds
        setTimeout(connect, 3000);
      };

      ws.onerror = () => {
        setIsConnected(false);
        wsRef.current = null;
      };
    };

    connect();

    return () => {
      wsRef.current?.close();
    };
  }, []);

  const sendCommand = (command: string) => {
    if (wsRef.current && isConnected) {
      wsRef.current.send(JSON.stringify({ type: 'command', data: command }));
    }
  };

  const clearOutput = () => {
    setOutput('');
  };

  return {
    output,
    sendCommand,
    clearOutput,
    isConnected
  };
}
