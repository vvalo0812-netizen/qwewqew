import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useTerminal } from '@/hooks/useTerminal';
import { ExternalLink, Maximize2 } from 'lucide-react';

export default function Terminal() {
  const terminalRef = useRef<HTMLDivElement>(null);
  const [command, setCommand] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [terminalTheme, setTerminalTheme] = useState('matrix');
  const { output, sendCommand, clearOutput, isConnected } = useTerminal();
  
  // Load terminal theme from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('terminalTheme') || 'matrix';
    setTerminalTheme(savedTheme);
  }, []);
  
  const getTerminalColors = (theme: string) => {
    const themes = {
      matrix: {
        bg: 'bg-black',
        text: 'text-green-400',
        border: 'border-green-600',
        header: 'bg-gray-800'
      },
      amber: {
        bg: 'bg-black',
        text: 'text-orange-400',
        border: 'border-orange-600',
        header: 'bg-orange-900'
      },
      blue: {
        bg: 'bg-gray-900',
        text: 'text-blue-400',
        border: 'border-blue-600',
        header: 'bg-blue-900'
      },
      white: {
        bg: 'bg-gray-800',
        text: 'text-white',
        border: 'border-gray-500',
        header: 'bg-gray-700'
      },
      red: {
        bg: 'bg-gray-900',
        text: 'text-red-400',
        border: 'border-red-600',
        header: 'bg-red-900'
      }
    };
    return themes[theme as keyof typeof themes] || themes.matrix;
  };
  
  const colors = getTerminalColors(terminalTheme);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [output]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (command.trim() && isConnected) {
      // Add to command history
      setCommandHistory(prev => [...prev.slice(-49), command.trim()]); // Keep last 50 commands
      setHistoryIndex(-1);
      
      sendCommand(command);
      setCommand('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit(e);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const newIndex = historyIndex + 1;
        if (newIndex < commandHistory.length) {
          setHistoryIndex(newIndex);
          setCommand(commandHistory[commandHistory.length - 1 - newIndex]);
        }
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setCommand(commandHistory[commandHistory.length - 1 - newIndex]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setCommand('');
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      // Simple tab completion for common commands
      const commonCommands = ['ls', 'pwd', 'cat', 'echo', 'clear', 'cls', 'help', 'whoami', 'ps', 'uname'];
      const matches = commonCommands.filter(cmd => cmd.startsWith(command.toLowerCase()));
      if (matches.length === 1) {
        setCommand(matches[0] + ' ');
      }
    }
  };

  const openInNewWindow = () => {
    const newWindow = window.open('', '_blank', 'width=800,height=600,menubar=no,toolbar=no,status=no');
    if (newWindow) {
      newWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Sora Terminal</title>
          <style>
            body { margin: 0; padding: 0; background: black; color: #00ff00; font-family: 'Courier New', monospace; }
            .terminal { height: 100vh; display: flex; flex-direction: column; }
            .output { flex: 1; padding: 20px; overflow-y: auto; white-space: pre-wrap; font-size: 14px; }
            .input-area { border-top: 1px solid #333; padding: 10px; display: flex; gap: 10px; }
            .input-area input { flex: 1; background: black; border: 1px solid #333; color: #00ff00; padding: 8px; font-family: inherit; }
            .input-area button { background: #333; border: 1px solid #666; color: #00ff00; padding: 8px 15px; cursor: pointer; }
            .input-area button:hover { background: #555; }
          </style>
        </head>
        <body>
          <div class="terminal">
            <div class="output" id="output">${output || 'Sora Terminal - Отдельное окно'}</div>
            <div class="input-area">
              <span>$</span>
              <input type="text" id="command" placeholder="Введите команду..." />
              <button onclick="executeCommand()">Execute</button>
            </div>
          </div>
          <script>
            const ws = new WebSocket('ws://localhost:5000');
            const outputEl = document.getElementById('output');
            const commandEl = document.getElementById('command');
            
            ws.onmessage = (event) => {
              const message = JSON.parse(event.data);
              if (message.type === 'output') {
                outputEl.textContent += message.data;
                outputEl.scrollTop = outputEl.scrollHeight;
              }
            };
            
            function executeCommand() {
              const cmd = commandEl.value.trim();
              if (cmd && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: 'command', data: cmd }));
                commandEl.value = '';
              }
            }
            
            commandEl.addEventListener('keydown', (e) => {
              if (e.key === 'Enter') executeCommand();
            });
          </script>
        </body>
        </html>
      `);
      newWindow.document.close();
    }
  };

  return (
    <div className={`h-full flex flex-col bg-gradient-to-b from-gray-900 to-black ${colors.text} font-mono`}>
      {/* Terminal Header */}
      <div className={`flex items-center justify-between px-4 py-2 ${colors.header} border-b ${colors.border}`}>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
          <span className="ml-2 text-sm text-gray-300">крис@osint-platform:~/tools</span>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            size="sm" 
            variant="ghost"
            onClick={clearOutput}
            className="text-gray-400 hover:text-white"
            title="Очистить терминал"
          >
            Clear
          </Button>
          <Button 
            size="sm" 
            variant="ghost"
            onClick={openInNewWindow}
            className="text-gray-400 hover:text-white"
            title="Открыть в отдельном окне"
          >
            <ExternalLink className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Terminal Output */}
      <div 
        ref={terminalRef}
        className={`flex-1 p-4 overflow-y-auto whitespace-pre-wrap text-sm ${colors.bg}`}
        data-testid="terminal-output"
        style={{ fontFamily: 'Consolas, "Liberation Mono", Menlo, Courier, monospace' }}
      >
        {output || 'Connecting to terminal...\nType "help" for available commands.'}
      </div>

      {/* Command Input */}
      <div className={`border-t ${colors.border} p-3 ${colors.header}`}>
        <form onSubmit={handleSubmit} className="flex space-x-2">
          <span className={`${colors.text} self-center font-bold`}>$</span>
          <Input
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Введите команду... (Tab для автодополнения, ↑↓ для истории)"
            className={`flex-1 ${colors.bg} ${colors.border} ${colors.text} focus:${colors.border} font-mono`}
            disabled={!isConnected}
            data-testid="input-terminal-command"
            autoComplete="off"
          />
          <Button 
            type="submit" 
            variant="outline" 
            disabled={!isConnected || !command.trim()}
            data-testid="button-execute-command"
            className={`${colors.border} ${colors.text} hover:bg-opacity-20`}
          >
            Execute
          </Button>
        </form>
        {!isConnected && (
          <p className="text-red-400 text-xs mt-2">Disconnected from terminal</p>
        )}
        <p className="text-gray-500 text-xs mt-1">
          Подсказки: cls/clear - очистка, help - справка, Tab - автодополнение
        </p>
      </div>
    </div>
  );
}
