import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings, Home, Phone, Globe, Users, FolderOpen, Terminal, MessageSquare, PlusCircle, Bot, UserCircle, Music, Database, Search, Eye, MapPin } from "lucide-react";

interface SidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
  providers: Array<{name: string, status: boolean, models: string[]}>;
  position?: 'left' | 'right' | 'top' | 'bottom';
}

export default function Sidebar({ activeView, onViewChange, providers, position = 'left' }: SidebarProps) {
  const menuItems = [
    { id: 'overview', label: 'Главная', icon: Home },
    { id: 'phone', label: 'Анализ телефонов', icon: Phone },
    { id: 'web', label: 'Анализ доменов', icon: Globe },
    { id: 'social', label: 'Соц. сети', icon: Users },
    { id: 'ip-lookup', label: 'Пробив IP', icon: MapPin },
    { id: 'osint-sites', label: 'OSINT Сайты', icon: Search },
    { id: 'google-dorks', label: 'Google Dorks', icon: Eye },
    { id: 'database-search', label: 'Поиск по БД', icon: Database },
    { id: 'telegram-bots', label: 'Telegram Боты', icon: Bot },
    { id: 'settings', label: 'Настройки', icon: Settings },
    { id: 'music', label: 'Музыка', icon: Music },
    { id: 'files', label: 'Файлы', icon: FolderOpen },
    { id: 'terminal', label: 'Терминал', icon: Terminal },
    { id: 'ai-chat', label: 'ИИ Чат', icon: MessageSquare },
    { id: 'author', label: 'О команде', icon: UserCircle },
  ];

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center shadow-lg pulse-glow">
            <i className="fas fa-robot text-white text-lg"></i>
          </div>
          <div>
            <h1 className="text-lg font-semibold text-gradient">Sora</h1>
            <p className="text-xs text-muted-foreground">OSINT Platform</p>
          </div>
          <div className="text-lg">空</div>
        </div>
      </div>

      {/* AI Status */}
      <div className="p-4 border-b border-border">
        <h3 className="text-sm font-medium mb-3">AI Models</h3>
        <div className="space-y-2">
          {providers.map((provider) => (
            <div key={provider.name} className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{provider.name}</span>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${provider.status ? 'status-online' : 'status-offline'}`}></div>
                <span className="text-xs text-muted-foreground">
                  {provider.status ? 'Online' : 'Offline'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={activeView === item.id ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => onViewChange(item.id)}
                data-testid={`nav-${item.id}`}
              >
                <Icon className="w-4 h-4 mr-3" />
                {item.label}
              </Button>
            );
          })}
        </div>

        <div className="mt-8">
          <h3 className="text-sm font-medium mb-3 text-muted-foreground">Custom Tools</h3>
          <Button
            variant="ghost"
            className="w-full justify-start text-sm"
            onClick={() => onViewChange('files')}
            data-testid="button-add-tool"
          >
            <PlusCircle className="w-4 h-4 mr-3 text-primary" />
            Add Tool
          </Button>
        </div>
      </nav>

      {/* Settings */}
      <div className="p-4 border-t border-border">
        <Button
          variant="ghost"
          className="w-full justify-start"
          data-testid="button-settings"
        >
          <Settings className="w-4 h-4 mr-3" />
          Settings
        </Button>
      </div>
    </aside>
  );
}
