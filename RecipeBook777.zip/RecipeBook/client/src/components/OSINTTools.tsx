import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Phone, Globe, Users, Search, Shield, Wifi } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface OSINTToolsProps {
  type: 'phone' | 'web' | 'social';
}

interface AnalysisResult {
  target: string;
  type: string;
  results: any;
  timestamp: string;
  status: 'success' | 'error';
  error?: string;
}

export default function OSINTTools({ type }: OSINTToolsProps) {
  const [target, setTarget] = useState('');
  const [results, setResults] = useState<AnalysisResult | null>(null);
  const { toast } = useToast();

  const analysisMutation = useMutation({
    mutationFn: async ({ target, type }: { target: string; type: string }) => {
      const response = await apiRequest('POST', '/api/osint/analyze', { target, type });
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
      toast({
        title: "Analysis Complete",
        description: `${type} analysis for ${target} completed`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAnalyze = () => {
    if (!target.trim()) return;
    analysisMutation.mutate({ target: target.trim(), type });
  };

  const getIcon = () => {
    switch (type) {
      case 'phone': return Phone;
      case 'web': return Globe;
      case 'social': return Users;
    }
  };

  const getTitle = () => {
    switch (type) {
      case 'phone': return 'Phone Analysis';
      case 'web': return 'Web Analysis';
      case 'social': return 'Social Media Analysis';
    }
  };

  const getPlaceholder = () => {
    switch (type) {
      case 'phone': return 'Enter phone number (e.g., +1234567890)';
      case 'web': return 'Enter domain or URL (e.g., example.com)';
      case 'social': return 'Enter username or handle (e.g., @username)';
    }
  };

  const Icon = getIcon();

  const renderPhoneTools = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Phone className="w-5 h-5 mr-2" />
            Carrier Detection
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Identify mobile network provider and location information
          </p>
          <Button size="sm" variant="outline" className="w-full">
            Run Analysis
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="w-5 h-5 mr-2" />
            Number Validation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Validate phone number format and check if it's active
          </p>
          <Button size="sm" variant="outline" className="w-full">
            Validate
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderWebTools = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="w-5 h-5 mr-2" />
            WHOIS Lookup
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Get domain registration and ownership information
          </p>
          <Button size="sm" variant="outline" className="w-full">
            Run WHOIS
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Wifi className="w-5 h-5 mr-2" />
            DNS Records
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Analyze DNS configuration and server information
          </p>
          <Button size="sm" variant="outline" className="w-full">
            Check DNS
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="w-5 h-5 mr-2" />
            SSL Certificate
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Examine SSL certificate details and security
          </p>
          <Button size="sm" variant="outline" className="w-full">
            Check SSL
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Globe className="w-5 h-5 mr-2" />
            Subdomain Enum
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Discover subdomains and web assets
          </p>
          <Button size="sm" variant="outline" className="w-full">
            Find Subdomains
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderSocialTools = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="w-5 h-5 mr-2" />
            Username Check
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Check username availability across social platforms
          </p>
          <Button size="sm" variant="outline" className="w-full">
            Check Platforms
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="w-5 h-5 mr-2" />
            Profile Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Analyze public profile information and connections
          </p>
          <Button size="sm" variant="outline" className="w-full">
            Analyze Profile
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderResults = () => {
    if (!results) return null;

    return (
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Analysis Results
            <Badge variant={results.status === 'success' ? 'default' : 'destructive'}>
              {results.status}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium">Target: {results.target}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(results.timestamp).toLocaleString()}
              </p>
            </div>

            {results.status === 'error' ? (
              <div className="p-3 bg-destructive/10 rounded-lg">
                <p className="text-destructive">{results.error}</p>
              </div>
            ) : (
              <Tabs defaultValue="analysis" className="w-full">
                <TabsList>
                  <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
                  <TabsTrigger value="raw">Raw Data</TabsTrigger>
                </TabsList>
                
                <TabsContent value="analysis" className="mt-4">
                  <div className="p-4 bg-secondary rounded-lg">
                    <pre className="whitespace-pre-wrap text-sm">
                      {JSON.stringify(results.results.analysis, null, 2)}
                    </pre>
                  </div>
                </TabsContent>
                
                <TabsContent value="raw" className="mt-4">
                  <div className="p-4 bg-secondary rounded-lg">
                    <pre className="whitespace-pre-wrap text-sm">
                      {JSON.stringify(results.results, null, 2)}
                    </pre>
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold flex items-center">
          <Icon className="w-6 h-6 mr-3 text-primary" />
          {getTitle()}
        </h2>
        <p className="text-muted-foreground">
          Professional OSINT tools for {type} analysis
        </p>
      </div>

      {/* Target Input */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Target Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-3">
            <Input
              placeholder={getPlaceholder()}
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="flex-1"
              data-testid={`input-${type}-target`}
            />
            <Button 
              onClick={handleAnalyze}
              disabled={!target.trim() || analysisMutation.isPending}
              data-testid={`button-analyze-${type}`}
            >
              {analysisMutation.isPending ? 'Analyzing...' : 'Analyze'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Available Tools */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Available Tools</CardTitle>
        </CardHeader>
        <CardContent>
          {type === 'phone' && renderPhoneTools()}
          {type === 'web' && renderWebTools()}
          {type === 'social' && renderSocialTools()}
        </CardContent>
      </Card>

      {/* Results */}
      {renderResults()}
    </div>
  );
}
