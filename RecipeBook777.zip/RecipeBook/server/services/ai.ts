import OpenAI from "openai";

interface AIProvider {
  name: string;
  client: OpenAI;
  models: string[];
}

class AIService {
  private providers: Map<string, AIProvider> = new Map();

  constructor() {
    this.initializeProviders();
  }

  private initializeProviders() {
    // Initialize xAI Grok - using blueprint integration
    if (process.env.XAI_API_KEY) {
      const grokClient = new OpenAI({
        baseURL: "https://api.x.ai/v1",
        apiKey: process.env.XAI_API_KEY,
      });
      
      this.providers.set('grok', {
        name: 'xAI Grok',
        client: grokClient,
        models: ['grok-2-1212', 'grok-2-vision-1212', 'grok-beta', 'grok-vision-beta']
      });
      console.log('✅ xAI Grok initialized with API key');
    } else {
      console.log('⚠️  XAI_API_KEY not found, Grok will use demo mode');
    }

    // Initialize OpenAI - using blueprint integration  
    if (process.env.OPENAI_API_KEY) {
      const openaiClient = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });
      
      this.providers.set('openai', {
        name: 'OpenAI GPT',
        client: openaiClient,
        models: ['gpt-5', 'gpt-4o', 'gpt-4']
      });
      console.log('✅ OpenAI initialized with API key');
    } else {
      console.log('⚠️  OPENAI_API_KEY not found, OpenAI will use demo mode');
    }

    // Initialize DeepSeek
    if (process.env.DEEPSEEK_API_KEY) {
      const deepseekClient = new OpenAI({
        baseURL: "https://api.deepseek.com/v1",
        apiKey: process.env.DEEPSEEK_API_KEY,
      });
      
      this.providers.set('deepseek', {
        name: 'DeepSeek',
        client: deepseekClient,
        models: ['deepseek-chat', 'deepseek-coder']
      });
      console.log('✅ DeepSeek initialized with API key');
    } else {
      console.log('⚠️  DEEPSEEK_API_KEY not found, DeepSeek will use demo mode');
    }
  }

  async chat(provider: string, messages: any[], model?: string): Promise<string> {
    const aiProvider = this.providers.get(provider);
    if (!aiProvider) {
      // Fallback to demo mode if no real providers available
      return this.getDemoResponse(provider, messages);
    }

    const selectedModel = model || aiProvider.models[0];
    
    try {
      const response = await aiProvider.client.chat.completions.create({
        model: selectedModel,
        messages,
        max_tokens: 4000,
        temperature: 0.7,
      });

      return response.choices[0]?.message?.content || "No response generated";
    } catch (error: any) {
      throw new Error(`${aiProvider.name} API error: ${error.message}`);
    }
  }

  async analyzeWithAI(provider: string, target: string, type: string): Promise<any> {
    const systemPrompt = this.getAnalysisPrompt(type);
    const userPrompt = `Analyze this ${type}: ${target}`;

    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ];

    try {
      const response = await this.chat(provider, messages);
      return {
        analysis: response,
        provider,
        model: this.providers.get(provider)?.models[0],
        timestamp: new Date().toISOString()
      };
    } catch (error: any) {
      throw new Error(`Analysis failed: ${error.message}`);
    }
  }

  private getAnalysisPrompt(type: string): string {
    const prompts = {
      phone: `You are an OSINT expert specializing in phone number analysis. Provide a comprehensive analysis including:
      
1. 📞 **CARRIER & LOCATION:**
   - Mobile network provider identification
   - Geographic region/country
   - Number format validation (E.164 standard)
   - Porting history if available

2. 🔍 **GOOGLE DORKS FOR PHONE OSINT:**
   - "phone number" OR "tel:" OR "call:" OR "mobile:"
   - site:truecaller.com "phone number"
   - site:whitepages.com "phone number"
   - "phone number" filetype:pdf OR filetype:doc
   - "phone number" site:linkedin.com OR site:facebook.com

3. 🔗 **RECOMMENDED OSINT SOURCES:**
   - TrueCaller database lookup
   - WhitePages/YellowPages searches  
   - Social media reverse phone lookup
   - Business directory searches
   - Breach database searches (HaveIBeenPwned style)

4. ⚠️ **PRIVACY & SECURITY NOTES:**
   - Potential spam/scam indicators
   - VoIP vs mobile line detection
   - Historical usage patterns

Provide actionable intelligence for legitimate OSINT investigations.`,
      
      domain: `You are an OSINT expert specializing in domain and website analysis. Provide comprehensive intelligence including:

1. 🌐 **TECHNICAL RECONNAISSANCE:**
   - DNS records analysis (A, MX, NS, TXT, CNAME)
   - WHOIS registration details
   - SSL certificate information
   - CDN and hosting provider identification
   - Web technologies used (CMS, frameworks)

2. 🔍 **GOOGLE DORKS FOR DOMAIN OSINT:**
   - site:domain.com filetype:pdf OR filetype:doc
   - site:domain.com "admin" OR "login" OR "dashboard"
   - site:domain.com intitle:"Index of /"
   - site:domain.com "password" OR "passwd" OR "credentials"
   - site:domain.com inurl:"/wp-admin" OR inurl:"/admin"
   - "domain.com" site:pastebin.com OR site:github.com
   - "domain.com" "@domain.com" filetype:xls OR filetype:csv

3. 🕰️ **HISTORICAL ANALYSIS:**
   - Wayback Machine snapshots
   - Domain age and registration history
   - Previous ownership changes
   - Subdomain enumeration

4. 🔒 **SECURITY ASSESSMENT:**
   - Open ports and services
   - Security headers analysis
   - Potential vulnerabilities
   - Reputation and blacklist status

Provide structured intelligence for comprehensive domain investigation.`,
      
      social: `You are an OSINT expert specializing in social media investigation. Provide detailed analysis including:

1. 👥 **PLATFORM ENUMERATION:**
   - Cross-platform username availability
   - Account existence verification
   - Profile consistency analysis
   - Linked accounts discovery

2. 🔍 **GOOGLE DORKS FOR SOCIAL OSINT:**
   - "username" site:twitter.com OR site:instagram.com
   - "username" site:linkedin.com OR site:facebook.com
   - "username" site:github.com OR site:gitlab.com
   - "username" site:reddit.com OR site:tiktok.com
   - "username" "email" OR "contact" filetype:pdf
   - "username" site:pastebin.com OR site:justpaste.it
   - "@username" OR "username" dating sites

3. 📊 **PROFILE INTELLIGENCE:**
   - Public posts and activity patterns
   - Friend/follower network analysis
   - Location data from check-ins
   - Photos metadata and reverse image search
   - Bio information correlation

4. 🔗 **RECOMMENDED TOOLS:**
   - Sherlock for username enumeration
   - Social Searcher for monitoring
   - TinEye for reverse image searches
   - Pipl for people search aggregation

Provide actionable social media intelligence within legal boundaries.`,
      
      email: `You are an OSINT expert specializing in email address analysis. Provide comprehensive investigation including:

1. 📧 **EMAIL VALIDATION & ANALYSIS:**
   - Format validation (RFC 5322 compliance)
   - Domain reputation analysis
   - MX record verification
   - Disposable email detection
   - Catch-all configuration check

2. 🔍 **GOOGLE DORKS FOR EMAIL OSINT:**
   - "email@domain.com" filetype:pdf OR filetype:doc
   - "email@domain.com" site:linkedin.com OR site:github.com
   - "email@domain.com" "password" OR "leak" OR "dump"
   - "email@domain.com" site:pastebin.com OR site:justpaste.it
   - "@domain.com" "employees" OR "staff" OR "team"
   - "email@domain.com" "resume" OR "CV" filetype:pdf

3. 🔒 **BREACH & LEAK ANALYSIS:**
   - HaveIBeenPwned database checks
   - DeHashed historical breaches
   - Paste site monitoring
   - Dark web marketplace presence

4. 🌐 **DOMAIN CORRELATION:**
   - Associated domains and services
   - Email provider analysis
   - Corporate vs personal classification
   - Historical registration patterns

Provide intelligence while respecting privacy and data protection laws.`,
      
      general: `You are an elite OSINT analyst with expertise across all domains. Conduct comprehensive analysis using:

1. 🎯 **TARGET CLASSIFICATION:**
   - Identify target type (person, domain, organization, etc.)
   - Determine investigation scope and approach
   - Assess available attack vectors

2. 🔍 **ADVANCED GOOGLE DORKS:**
   - Custom dorks based on target characteristics
   - Multi-stage dorking strategies
   - Time-sensitive search operations
   - Geographic and language-specific searches

3. 🔗 **OSINT FRAMEWORK INTEGRATION:**
   - Maltego for link analysis
   - OSINT Framework tool selection
   - Automated reconnaissance tools
   - Manual verification techniques

4. 📈 **INTELLIGENCE CORRELATION:**
   - Cross-reference multiple sources
   - Timeline reconstruction
   - Pattern recognition analysis
   - Confidence scoring for findings

Provide professional-grade OSINT analysis with actionable recommendations.`
    };

    return prompts[type as keyof typeof prompts] || prompts.general;
  }

  private getDemoResponse(provider: string, messages: any[]): string {
    const lastMessage = messages[messages.length - 1]?.content || '';
    const isOSINTQuery = /\b(phone|domain|email|social|username|ip|whois|dns|osint|investigate|analysis|dork|google)\b/i.test(lastMessage);
    
    const demoResponses = {
      grok: isOSINTQuery ? [
        `🕵️ **Grok OSINT Analysis (Demo Mode)**\n\n📱 **Target:** ${lastMessage.substring(0, 100)}${lastMessage.length > 100 ? '...' : ''}\n\n🔍 **OSINT Recommendations:**\n• Use Google Dorks: site:example.com "target"\n• Check social media platforms\n• Verify through WHOIS databases\n• Cross-reference with breach databases\n\n⚠️ **Note:** This is demo mode. Add XAI_API_KEY for real-time analysis with detailed Google Dorks and actionable intelligence.`,
        `🎯 **Grok Tactical Analysis (Demo)**\n\n📋 **Investigation Strategy:**\n1. 🔎 Primary reconnaissance via search engines\n2. 🌐 Social media enumeration\n3. 📊 Public records analysis\n4. 🔐 Security assessment\n\n💡 **Suggested Google Dorks:**\n• "${lastMessage.split(' ')[0]}" filetype:pdf\n• site:linkedin.com "${lastMessage.split(' ')[0]}"\n• "${lastMessage.split(' ')[0]}" "email" OR "contact"\n\n🔑 **Full Analysis:** Requires XAI_API_KEY for complete OSINT framework integration.`
      ] : [
        `🤖 **Grok Chat (Demo Mode)**\n\nВаш запрос: "${lastMessage.substring(0, 50)}..."\n\nЭто демонстрационный режим Grok. Для доступа к полной функциональности xAI Grok, включая:\n• Расширенный анализ текста\n• Мультимодальные возможности\n• OSINT интеграцию\n\nДобавьте XAI_API_KEY в настройки приложения.`,
        `⚡ **Grok Processing (Demo)**\n\n${lastMessage}\n\nВ реальном режиме Grok предоставляет:\n• Детальный контекстуальный анализ\n• Интеграцию с внешними источниками\n• Специализированные OSINT возможности\n\n🔑 Активируйте с помощью XAI_API_KEY`
      ],
      
      deepseek: isOSINTQuery ? [
        `🧠 **DeepSeek OSINT Framework (Demo)**\n\n🎯 **Target Analysis:** ${lastMessage.substring(0, 100)}${lastMessage.length > 100 ? '...' : ''}\n\n🔧 **Technical Assessment:**\n• DNS enumeration patterns\n• Subdomain discovery methods\n• Certificate transparency logs\n• Port scanning recommendations\n\n💻 **Code-Based Tools:**\n\`\`\`bash\n# Example reconnaissance script\nnslookup target.com\nwhois target.com\ndig target.com ANY\n\`\`\`\n\n🔑 **Full Framework:** Add DEEPSEEK_API_KEY for complete technical analysis and custom tool generation.`,
        `🔍 **DeepSeek Technical Intel (Demo)**\n\n📊 **Analysis Framework:**\n1. 🛡️ Security posture assessment\n2. 🌐 Infrastructure mapping\n3. 📱 Mobile app analysis\n4. 🔒 API endpoint discovery\n\n🐍 **Python OSINT Tools:**\n\`\`\`python\n# Sample investigation script\nimport requests\nimport json\n\ndef analyze_target(target):\n    # Real implementation available with API key\n    pass\n\`\`\`\n\n💡 Enable full capabilities with DEEPSEEK_API_KEY`
      ] : [
        `🧠 **DeepSeek Chat (Demo Mode)**\n\nАнализирую: "${lastMessage.substring(0, 50)}..."\n\nЭто демонстрационный ответ. DeepSeek специализируется на:\n• Техническом анализе кода\n• Создании OSINT инструментов\n• Автоматизации расследований\n\nДобавьте DEEPSEEK_API_KEY для полной функциональности.`,
        `💡 **DeepSeek Technical Response (Demo)**\n\n${lastMessage}\n\nВ полной версии предоставляю:\n• Детальный код-анализ\n• Создание custom OSINT скриптов\n• Техническую документацию\n• Интеграцию с внешними API\n\n🔑 Активация: DEEPSEEK_API_KEY`
      ],
      
      openai: isOSINTQuery ? [
        `🌟 **OpenAI GPT-5 OSINT Assistant (Demo)**\n\n🔍 **Investigation Target:** ${lastMessage.substring(0, 100)}${lastMessage.length > 100 ? '...' : ''}\n\n📋 **Comprehensive Analysis Plan:**\n• 🔎 Multi-source data correlation\n• 📊 Pattern recognition analysis\n• 🌐 Cross-platform verification\n• 📈 Risk assessment matrix\n\n🎯 **Advanced Google Dorks:**\n• \"${lastMessage.split(' ')[0]}\" (site:pastebin.com OR site:github.com)\n• filetype:pdf \"${lastMessage.split(' ')[0]}\" \"contact\"\n• \"${lastMessage.split(' ')[0]}\" intitle:\"resume\" OR intitle:\"CV\"\n\n🔑 **Full GPT-5 Analysis:** Requires OPENAI_API_KEY for advanced multimodal capabilities.`,
        `🚀 **GPT-5 Professional OSINT (Demo)**\n\n🎭 **Target Profile Development:**\n1. 📱 Digital footprint mapping\n2. 🔗 Relationship network analysis\n3. 📍 Geolocation correlation\n4. ⏰ Timeline reconstruction\n\n🛠️ **Recommended Tools Integration:**\n• Maltego for link analysis\n• Shodan for infrastructure scan\n• Social media APIs\n• Breach databases\n\n💎 Unlock GPT-5's full potential with OPENAI_API_KEY`
      ] : [
        `🌟 **OpenAI GPT-5 (Demo Mode)**\n\nЗапрос: "${lastMessage.substring(0, 50)}..."\n\n• 🧠 GPT-5 - самая современная модель (выпущена 7 августа 2025)\n• 🎯 Расширенные возможности анализа\n• 🖼️ Мультимодальная обработка\n• 🔍 Специализированная OSINT поддержка\n\nДля активации всех функций добавьте OPENAI_API_KEY.`,
        `💫 **GPT-5 Advanced Response (Demo)**\n\n${lastMessage}\n\nВ полном режиме GPT-5 предоставляет:\n• Контекстуальный анализ на 131k токенов\n• Обработка изображений и текста\n• Интеграцию с внешними источниками\n• Персонализированные рекомендации\n\n🔑 Активируйте с OPENAI_API_KEY`
      ]
    };
    
    const responses = demoResponses[provider as keyof typeof demoResponses] || demoResponses.grok;
    return responses[Math.floor(Math.random() * responses.length)];
  }

  getAvailableProviders(): Array<{name: string, status: boolean, models: string[]}> {
    const providers = [];
    
    // Add real providers
    for (const [key, provider] of Array.from(this.providers.entries())) {
      providers.push({
        name: provider.name,
        status: true,
        models: provider.models
      });
    }
    
    // Always show all providers (demo mode available)
    if (!this.providers.has('grok')) {
      providers.push({ 
        name: 'xAI Grok', 
        status: true, // Demo mode available
        models: ['grok-2-1212', 'grok-beta'] 
      });
    }
    if (!this.providers.has('deepseek')) {
      providers.push({ 
        name: 'DeepSeek', 
        status: true, // Demo mode available
        models: ['deepseek-chat', 'deepseek-coder'] 
      });
    }
    if (!this.providers.has('openai')) {
      providers.push({ 
        name: 'OpenAI GPT', 
        status: true, // Demo mode available
        models: ['gpt-5', 'gpt-4o'] 
      });
    }

    return providers;
  }
}

export const aiService = new AIService();
