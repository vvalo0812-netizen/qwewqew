import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage.js";
import { aiService } from "./services/ai.js";
import { terminalService } from "./services/terminal.js";
import { osintService } from "./services/osint.js";

// Database search simulation function
async function performDatabaseSearch(searchPath: string) {
  const timestamp = new Date().toISOString();
  const pathParts = searchPath.toLowerCase().split('.');
  
  // Simulate searching different data sources based on path
  const mockData: any = {
    users: {
      phone: ["+1234567890", "+9876543210", "+5555555555"],
      email: ["user@example.com", "admin@domain.com", "test@mail.ru"],
      id: ["user123", "admin456", "guest789"],
      name: ["Иван Иванов", "Петр Петров", "Анна Сидорова"]
    },
    analysis: {
      phone_number: [
        { number: "+1234567890", country: "US", operator: "AT&T", valid: true },
        { number: "+79161234567", country: "RU", operator: "МТС", valid: true }
      ],
      domain: [
        { domain: "example.com", ip: "93.184.216.34", status: "active" },
        { domain: "test.ru", ip: "127.0.0.1", status: "inactive" }
      ],
      results: [
        { type: "phone", target: "+1234567890", status: "completed", data: "Найден пользователь" },
        { type: "email", target: "test@mail.ru", status: "completed", data: "Аккаунт активен" }
      ]
    },
    osint: {
      data: [
        { source: "социальные сети", info: "Профиль ВКонтакте найден" },
        { source: "мессенджеры", info: "Telegram аккаунт активен" },
        { source: "публичные данные", info: "Упоминания в новостях" }
      ],
      investigations: [
        { id: "inv001", target: "Иван Иванов", status: "active", priority: "high" },
        { id: "inv002", target: "+79161234567", status: "completed", priority: "medium" }
      ]
    },
    telegram: {
      bots: [
        { name: "Eye of Beholder", username: "@eyeofbeholder_bot", status: "active" },
        { name: "GetContact Info", username: "@getcontact_real_bot", status: "active" }
      ],
      channels: [
        { name: "OSINT Community", members: 15000, category: "education" },
        { name: "Tech News", members: 8500, category: "news" }
      ]
    }
  };

  let found = false;
  let data = "Данные не найдены";
  let type = "unknown";

  try {
    // Try to navigate to the specified path
    let current = mockData;
    
    for (const part of pathParts) {
      if (current && typeof current === 'object' && part in current) {
        current = current[part];
        found = true;
      } else {
        found = false;
        break;
      }
    }

    if (found && current !== undefined) {
      data = current;
      type = pathParts[0] || "general";
      
      // Add some intelligence based on search terms
      if (searchPath.includes('phone') || searchPath.includes('телефон')) {
        type = "phone_analysis";
      } else if (searchPath.includes('email') || searchPath.includes('почта')) {
        type = "email_analysis";
      } else if (searchPath.includes('domain') || searchPath.includes('домен')) {
        type = "domain_analysis";
      } else if (searchPath.includes('user') || searchPath.includes('пользователь')) {
        type = "user_data";
      } else if (searchPath.includes('osint') || searchPath.includes('расследование')) {
        type = "osint_investigation";
      }
    }
  } catch (error) {
    found = false;
    data = `Ошибка поиска: ${error}`;
  }

  return {
    path: searchPath,
    data,
    type,
    found,
    timestamp
  };
}

const upload = multer({ 
  dest: path.join(process.cwd(), 'uploads'),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // AI Chat endpoint
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { provider, messages, model } = req.body;
      
      if (!provider || !messages) {
        return res.status(400).json({ error: "Provider and messages are required" });
      }

      const response = await aiService.chat(provider, messages, model);
      res.json({ response, provider, model });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get available AI providers
  app.get("/api/ai/providers", (req, res) => {
    const providers = aiService.getAvailableProviders();
    res.json(providers);
  });

  // OSINT Analysis endpoints
  app.post("/api/osint/analyze", async (req, res) => {
    try {
      const { target, type } = req.body;
      
      if (!target || !type) {
        return res.status(400).json({ error: "Target and type are required" });
      }

      let result;
      switch (type) {
        case 'phone':
          result = await osintService.analyzePhone(target);
          break;
        case 'domain':
          result = await osintService.analyzeDomain(target);
          break;
        case 'social':
          result = await osintService.analyzeSocialMedia(target);
          break;
        case 'email':
          result = await osintService.analyzeEmail(target);
          break;
        default:
          return res.status(400).json({ error: "Invalid analysis type" });
      }

      // Save result to storage
      await storage.createAnalysisResult({
        type: result.type,
        target: result.target,
        results: result.results,
        status: result.status === 'success' ? 'completed' : 'failed'
      });

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get analysis history
  app.get("/api/osint/history", async (req, res) => {
    try {
      const results = await storage.getAnalysisResults();
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Custom tool upload
  app.post("/api/tools/upload", upload.single('tool'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const { name, description } = req.body;
      const toolsDir = path.join(process.cwd(), 'tools');
      
      // Ensure tools directory exists
      if (!fs.existsSync(toolsDir)) {
        fs.mkdirSync(toolsDir, { recursive: true });
      }

      // Move file to tools directory
      const finalPath = path.join(toolsDir, req.file.originalname);
      fs.renameSync(req.file.path, finalPath);

      // Save to storage
      const tool = await storage.createCustomTool({
        name: name || req.file.originalname,
        filename: req.file.originalname,
        description: description || "",
        filePath: finalPath
      });

      res.json(tool);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get custom tools
  app.get("/api/tools", async (req, res) => {
    try {
      const tools = await storage.getCustomTools();
      res.json(tools);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Execute custom tool
  app.post("/api/tools/execute", async (req, res) => {
    try {
      const { toolId, args } = req.body;
      const tool = await storage.getCustomTool(toolId);
      
      if (!tool) {
        return res.status(404).json({ error: "Tool not found" });
      }

      // Execute the tool using terminal service
      const output = await terminalService.executeOSINTTool(tool.filename, args || "");
      res.json({ output, tool: tool.name });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);

  // WebSocket for terminal
  const wss = new WebSocketServer({ server: httpServer });

  wss.on('connection', (ws, req) => {
    const sessionId = `session-${Date.now()}-${Math.random()}`;
    const session = terminalService.createSession(sessionId);

    // Send terminal output to client
    session.emitter.on('output', (data) => {
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({ type: 'output', data }));
      }
    });

    // Handle incoming commands
    ws.on('message', (message) => {
      try {
        const { type, data } = JSON.parse(message.toString());
        
        if (type === 'command') {
          terminalService.executeCommand(sessionId, data);
        }
      } catch (error) {
        ws.send(JSON.stringify({ type: 'error', data: 'Invalid message format' }));
      }
    });

    // Cleanup on disconnect
    ws.on('close', () => {
      terminalService.destroySession(sessionId);
    });

    // Send welcome message
    ws.send(JSON.stringify({ 
      type: 'output', 
      data: 'Connected to OSINT terminal. Type "help" for available commands.\n' 
    }));
  });

  // Telegram Bots endpoints
  app.get("/api/telegram-bots", async (req, res) => {
    try {
      const bots = await storage.getTelegramBots();
      res.json(bots);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/telegram-bots", async (req, res) => {
    try {
      const bot = await storage.createTelegramBot(req.body);
      res.json(bot);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/telegram-bots/:id", async (req, res) => {
    try {
      const bot = await storage.updateTelegramBot(req.params.id, req.body);
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }
      res.json(bot);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/telegram-bots/:id", async (req, res) => {
    try {
      const success = await storage.deleteTelegramBot(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Bot not found" });
      }
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Database Search endpoint
  app.post("/api/database/search", async (req, res) => {
    try {
      const { path } = req.body;
      
      if (!path) {
        return res.status(400).json({ error: "Search path is required" });
      }

      // Simulate database search based on path
      const result = await performDatabaseSearch(path);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Author Info endpoints
  app.get("/api/author", async (req, res) => {
    try {
      const author = await storage.getAuthorInfo();
      res.json(author);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/author", async (req, res) => {
    try {
      const author = await storage.createOrUpdateAuthorInfo(req.body);
      res.json(author);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  return httpServer;
}
