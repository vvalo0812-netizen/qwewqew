const { app, BrowserWindow, Menu, dialog, ipcMain } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const serve = require('electron-serve');

// Настройка для dev/production
const isDev = process.env.NODE_ENV === 'development';
const port = process.env.PORT || 5000;

let mainWindow;
let serverProcess;

// Загрузчик для production
const loadURL = serve({ directory: 'dist' });

// Проверка пароля
let isAuthenticated = false;

function createWindow() {
  // Создание главного окна
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, 'icon.ico'),
    title: 'Sora OSINT Platform - Legal Intelligence Tools',
    show: false, // Не показываем пока не аутентифицированы
    titleBarStyle: 'default',
    frame: true,
    backgroundColor: '#0a0a0a'
  });

  // Настройка меню
  const template = [
    {
      label: 'Файл',
      submenu: [
        {
          label: 'Новое исследование',
          accelerator: 'CmdOrCtrl+N',
          click: () => {
            mainWindow.webContents.send('menu-action', 'new-investigation');
          }
        },
        {
          label: 'Открыть',
          accelerator: 'CmdOrCtrl+O',
          click: () => {
            mainWindow.webContents.send('menu-action', 'open-file');
          }
        },
        {
          label: 'Сохранить',
          accelerator: 'CmdOrCtrl+S',
          click: () => {
            mainWindow.webContents.send('menu-action', 'save-file');
          }
        },
        { type: 'separator' },
        {
          label: 'Выход',
          accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Ctrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: 'OSINT',
      submenu: [
        {
          label: 'Анализ телефонов',
          click: () => {
            mainWindow.webContents.send('navigate-to', 'phone');
          }
        },
        {
          label: 'Анализ доменов',
          click: () => {
            mainWindow.webContents.send('navigate-to', 'web');
          }
        },
        {
          label: 'Социальные сети',
          click: () => {
            mainWindow.webContents.send('navigate-to', 'social');
          }
        },
        {
          label: 'Telegram боты',
          click: () => {
            mainWindow.webContents.send('navigate-to', 'telegram-bots');
          }
        }
      ]
    },
    {
      label: 'Инструменты',
      submenu: [
        {
          label: 'Терминал',
          accelerator: 'CmdOrCtrl+T',
          click: () => {
            mainWindow.webContents.send('navigate-to', 'terminal');
          }
        },
        {
          label: 'Файловый менеджер',
          accelerator: 'CmdOrCtrl+F',
          click: () => {
            mainWindow.webContents.send('navigate-to', 'files');
          }
        },
        {
          label: 'ИИ Ассистент',
          accelerator: 'CmdOrCtrl+I',
          click: () => {
            mainWindow.webContents.send('navigate-to', 'ai-chat');
          }
        },
        {
          label: 'Музыка',
          click: () => {
            mainWindow.webContents.send('navigate-to', 'music');
          }
        }
      ]
    },
    {
      label: 'Помощь',
      submenu: [
        {
          label: 'О команде',
          click: () => {
            mainWindow.webContents.send('navigate-to', 'author');
          }
        },
        {
          label: 'Документация',
          click: () => {
            require('electron').shell.openExternal('https://github.com/sora-osint/docs');
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);

  // Функция аутентификации
  const showPasswordDialog = async () => {
    const result = await dialog.showMessageBox(mainWindow, {
      type: 'question',
      title: 'Sora OSINT Platform - Аутентификация',
      message: 'Добро пожаловать в Sora OSINT Platform!\n\nВведите пароль для доступа к системе:',
      detail: 'Это профессиональная платформа для OSINT исследований.\nДоступ только для авторизованных пользователей.',
      buttons: ['Войти', 'Отмена'],
      defaultId: 0,
      cancelId: 1,
      noLink: true
    });

    if (result.response === 0) {
      // Показываем диалог ввода пароля
      const { response } = await dialog.showMessageBox(mainWindow, {
        type: 'info',
        title: 'Введите пароль',
        message: 'Пароль:',
        detail: 'Введите пароль в следующем диалоге',
        buttons: ['OK']
      });
      
      // Простая проверка пароля (в реальном приложении используйте более безопасный метод)
      const password = await promptPassword();
      
      if (password === 'Amalya') {
        isAuthenticated = true;
        loadMainApp();
      } else {
        await dialog.showErrorBox('Ошибка', 'Неверный пароль! Доступ запрещен.');
        app.quit();
      }
    } else {
      app.quit();
    }
  };

  const promptPassword = () => {
    return new Promise((resolve) => {
      // Создаем временное окно для ввода пароля
      const passwordWindow = new BrowserWindow({
        width: 400,
        height: 200,
        modal: true,
        parent: mainWindow,
        webPreferences: {
          nodeIntegration: true,
          contextIsolation: false
        },
        frame: false,
        resizable: false
      });

      const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { 
              margin: 0; 
              padding: 20px; 
              font-family: -apple-system, BlinkMacSystemFont, sans-serif;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              color: white;
              display: flex;
              flex-direction: column;
              justify-content: center;
              align-items: center;
              height: 160px;
            }
            .container {
              text-align: center;
              background: rgba(255,255,255,0.1);
              padding: 20px;
              border-radius: 10px;
              backdrop-filter: blur(10px);
            }
            input { 
              padding: 10px; 
              margin: 10px 0; 
              border: none; 
              border-radius: 5px; 
              width: 200px;
              text-align: center;
              font-size: 16px;
            }
            button { 
              padding: 10px 20px; 
              margin: 5px; 
              border: none; 
              border-radius: 5px; 
              background: #4CAF50; 
              color: white; 
              cursor: pointer; 
              font-size: 14px;
            }
            button:hover { background: #45a049; }
            .cancel { background: #f44336; }
            .cancel:hover { background: #da190b; }
            h3 { margin: 0 0 15px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <h3>🔒 Sora OSINT Platform</h3>
            <input type="password" id="password" placeholder="Введите пароль" autofocus />
            <br/>
            <button onclick="submit()">Войти</button>
            <button class="cancel" onclick="cancel()">Отмена</button>
          </div>
          <script>
            const { ipcRenderer } = require('electron');
            function submit() {
              const pwd = document.getElementById('password').value;
              ipcRenderer.send('password-entered', pwd);
            }
            function cancel() {
              ipcRenderer.send('password-cancelled');
            }
            document.getElementById('password').addEventListener('keypress', function(e) {
              if (e.key === 'Enter') submit();
            });
          </script>
        </body>
        </html>
      `;
      
      passwordWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(htmlContent));

      ipcMain.once('password-entered', (event, password) => {
        passwordWindow.close();
        resolve(password);
      });

      ipcMain.once('password-cancelled', () => {
        passwordWindow.close();
        resolve('');
      });
    });
  };

  const loadMainApp = async () => {
    mainWindow.show();
    
    // Загружаем основное приложение
    if (isDev) {
      // В режиме разработки подключаемся к dev серверу
      await mainWindow.loadURL(`http://localhost:${port}`);
      mainWindow.webContents.openDevTools();
    } else {
      // В production загружаем встроенный сервер
      await mainWindow.loadURL(`http://127.0.0.1:${port}`);
    }
  };

  // Запускаем процесс аутентификации
  mainWindow.once('ready-to-show', () => {
    showPasswordDialog();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
    if (serverProcess) {
      serverProcess.kill();
    }
  });
}

// Запуск сервера в dev режиме
const startServer = () => {
  if (isDev) {
    return; // В dev режиме сервер уже должен быть запущен
  }
  
  // В production запускаем встроенный сервер
  const serverPath = path.join(__dirname, 'server.js');
  serverProcess = spawn('node', [serverPath], {
    stdio: 'pipe',
    cwd: __dirname
  });

  serverProcess.stdout.on('data', (data) => {
    console.log(`Server: ${data}`);
  });

  serverProcess.stderr.on('data', (data) => {
    console.error(`Server Error: ${data}`);
  });
};

app.whenReady().then(() => {
  startServer();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Обработка IPC сообщений
ipcMain.handle('app-version', () => {
  return app.getVersion();
});

ipcMain.handle('show-message-box', async (event, options) => {
  const result = await dialog.showMessageBox(mainWindow, options);
  return result;
});