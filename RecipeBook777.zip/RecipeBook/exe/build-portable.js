const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 Building Portable Sora.exe...');

// Create directories
if (!fs.existsSync('app')) fs.mkdirSync('app');
if (!fs.existsSync('build')) fs.mkdirSync('build');

// Copy files to app directory
console.log('📁 Copying application files...');

// Copy main files
fs.copyFileSync('main.js', 'app/main.js');
fs.copyFileSync('preload.js', 'app/preload.js');
fs.copyFileSync('server.js', 'app/server.js');
fs.copyFileSync('icon.png', 'app/icon.png');
fs.copyFileSync('icon.ico', 'app/icon.ico');

// Copy package.json for app
const appPackage = {
  "name": "sora-osint",
  "version": "1.0.0",
  "description": "Sora OSINT Platform - Professional OSINT Tools with AI Integration",
  "main": "main.js",
  "author": "Amalya (@cluim) & Шёпот (@oxaul)",
  "license": "MIT",
  "dependencies": {
    "electron-serve": "^1.1.0",
    "express": "^4.18.2"
  },
  "devDependencies": {
    "electron": "^28.0.0"
  }
};
fs.writeFileSync('app/package.json', JSON.stringify(appPackage, null, 2));

// Copy dist directory
if (fs.existsSync('dist')) {
  const copyDir = (src, dest) => {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    const entries = fs.readdirSync(src, { withFileTypes: true });
    
    for (let entry of entries) {
      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);
      
      if (entry.isDirectory()) {
        copyDir(srcPath, destPath);
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  };
  
  copyDir('dist', 'app/dist');
  console.log('✅ Frontend files copied');
}

// Install dependencies in app folder
console.log('📦 Installing app dependencies...');
try {
  execSync('npm install --production', { 
    cwd: path.join(__dirname, 'app'),
    stdio: 'inherit'
  });
} catch (error) {
  console.error('Error installing dependencies:', error.message);
}

// Build executable
console.log('⚡ Building executable...');
try {
  execSync('npx electron-builder --config.directories.app=app --config.win.artifactName=sora.exe --config.win.target=portable', {
    stdio: 'inherit'
  });
  console.log('🎉 ✨ sora.exe successfully built! ✨');
  console.log('📍 Location: exe/dist/sora.exe');
  console.log('🔑 Password: Amalya');
} catch (error) {
  console.error('Build failed:', error.message);
}