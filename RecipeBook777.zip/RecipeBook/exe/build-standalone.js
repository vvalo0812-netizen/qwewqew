const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 Building Standalone Sora.exe...');

// Create production build of the frontend
console.log('📦 Building frontend...');
try {
  execSync('npm run build', { 
    cwd: path.join(__dirname, '..'),
    stdio: 'inherit'
  });
  console.log('✅ Frontend built successfully');
} catch (error) {
  console.error('❌ Frontend build failed:', error.message);
  process.exit(1);
}

// Copy built files to exe/dist
console.log('📁 Copying frontend files...');
const execDir = __dirname;
const frontendDist = path.join(__dirname, '..', 'dist');
const exeDist = path.join(execDir, 'dist');

if (fs.existsSync(exeDist)) {
  fs.rmSync(exeDist, { recursive: true });
}

const copyDir = (src, dest) => {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  
  for (let entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
};

copyDir(frontendDist, exeDist);
console.log('✅ Frontend files copied');

// Create standalone server
console.log('⚡ Creating standalone server executable...');

// Update package.json for pkg
const packageJson = {
  "name": "sora-osint-server",
  "version": "1.0.0",
  "main": "server.js",
  "pkg": {
    "targets": ["node18-win-x64"],
    "outputPath": "./build",
    "scripts": ["server.js"],
    "assets": [
      "dist/**/*",
      "icon.png",
      "icon.ico"
    ]
  },
  "dependencies": {
    "express": "^4.18.2"
  }
};

fs.writeFileSync(path.join(execDir, 'package-pkg.json'), JSON.stringify(packageJson, null, 2));

try {
  // Use pkg to create standalone executable
  execSync(`npx pkg server.js --target node18-win-x64 --output ./build/sora-server.exe --config ./package-pkg.json`, {
    cwd: execDir,
    stdio: 'inherit'
  });
  console.log('✅ Standalone server created');
} catch (error) {
  console.warn('⚠️ pkg build failed, using Node.js fallback');
  
  // Fallback: create a portable Node.js solution
  const buildDir = path.join(execDir, 'build');
  if (!fs.existsSync(buildDir)) {
    fs.mkdirSync(buildDir, { recursive: true });
  }
  
  // Copy all files for portable version
  fs.copyFileSync(path.join(execDir, 'server.js'), path.join(buildDir, 'server.js'));
  fs.copyFileSync(path.join(execDir, 'package.json'), path.join(buildDir, 'package.json'));
  fs.copyFileSync(path.join(execDir, 'icon.png'), path.join(buildDir, 'icon.png'));
  fs.copyFileSync(path.join(execDir, 'icon.ico'), path.join(buildDir, 'icon.ico'));
  
  // Copy dist folder
  const buildDistDir = path.join(buildDir, 'dist');
  copyDir(exeDist, buildDistDir);
  
  console.log('✅ Portable version created');
}

// Create Windows launcher
console.log('🔧 Creating Windows launcher...');
const launcherContent = `@echo off
setlocal EnableDelayedExpansion

title Sora OSINT Platform v1.0.0
color 0A

echo.
echo  ███████  ██████  ██████   █████  
echo  ██      ██    ██ ██   ██ ██   ██ 
echo  ███████ ██    ██ ██████  ███████ 
echo       ██ ██    ██ ██   ██ ██   ██ 
echo  ███████  ██████  ██   ██ ██   ██ 
echo.
echo   Professional OSINT Platform v1.0.0
echo   Developed by Amalya (@cluim) ^& Shepot (@oxaul)
echo.
echo   Starting Sora OSINT Platform...
echo   Access: http://127.0.0.1:5000
echo   Password: Amalya
echo.

cd /d "%~dp0"

REM Check if sora-server.exe exists (standalone version)
if exist "sora-server.exe" (
    echo [INFO] Starting standalone server...
    sora-server.exe
) else (
    REM Fallback to Node.js
    echo [INFO] Starting Node.js server...
    
    REM Check if Node.js is installed
    where node >nul 2>nul
    if !ERRORLEVEL! NEQ 0 (
        echo [ERROR] Node.js is not installed!
        echo Please install Node.js from https://nodejs.org/
        echo Or use the standalone version.
        pause
        exit /b 1
    )
    
    REM Install dependencies if needed
    if not exist node_modules (
        echo [INFO] Installing dependencies...
        npm install --silent --production
    )
    
    REM Start the server
    node server.js
)

echo.
echo Server stopped. Press any key to exit...
pause >nul`;

fs.writeFileSync(path.join(execDir, 'build', 'sora.bat'), launcherContent);

// Create shortcut script
const shortcutScript = `$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\\Desktop\\Sora OSINT.lnk")
$Shortcut.TargetPath = "$PWD\\sora.bat"
$Shortcut.WorkingDirectory = "$PWD"
$Shortcut.IconLocation = "$PWD\\icon.ico"
$Shortcut.Description = "Sora OSINT Platform - Professional Intelligence Tools"
$Shortcut.Save()
Write-Host "Desktop shortcut created successfully!"`;

fs.writeFileSync(path.join(execDir, 'build', 'create-shortcut.ps1'), shortcutScript);

console.log('🎉 ✨ Sora OSINT Platform built successfully! ✨');
console.log('');
console.log('📂 Build location: ./exe/build/');
console.log('🚀 Run: sora.bat');
console.log('🔑 Password: Amalya');
console.log('🌐 Access: http://127.0.0.1:5000');
console.log('');
console.log('💡 To create desktop shortcut, run:');
console.log('   powershell -ExecutionPolicy Bypass -File create-shortcut.ps1');