import OpenAI from "openai";

interface AIProvider {
  name: string;
  client: OpenAI;
  models: string[];
}

class AIService {
  private providers: Map<string, AIProvider> = new Map();

  constructor() {
    this.initializeProviders();
  }

  private initializeProviders() {
    // Initialize xAI Grok
    if (process.env.XAI_API_KEY) {
      const grokClient = new OpenAI({
        baseURL: "https://api.x.ai/v1",
        apiKey: process.env.XAI_API_KEY,
      });
      
      this.providers.set('grok', {
        name: 'xAI Grok',
        client: grokClient,
        models: ['grok-2-1212', 'grok-2-vision-1212', 'grok-beta', 'grok-vision-beta']
      });
    }

    // Initialize DeepSeek
    if (process.env.DEEPSEEK_API_KEY) {
      const deepseekClient = new OpenAI({
        baseURL: "https://api.deepseek.com/v1",
        apiKey: process.env.DEEPSEEK_API_KEY,
      });
      
      this.providers.set('deepseek', {
        name: 'DeepSeek',
        client: deepseekClient,
        models: ['deepseek-chat', 'deepseek-coder']
      });
    }
  }

  async chat(provider: string, messages: any[], model?: string): Promise<string> {
    const aiProvider = this.providers.get(provider);
    if (!aiProvider) {
      throw new Error(`AI provider ${provider} not available. Check API keys.`);
    }

    const selectedModel = model || aiProvider.models[0];
    
    try {
      const response = await aiProvider.client.chat.completions.create({
        model: selectedModel,
        messages,
        max_tokens: 4000,
        temperature: 0.7,
      });

      return response.choices[0]?.message?.content || "No response generated";
    } catch (error: any) {
      throw new Error(`${aiProvider.name} API error: ${error.message}`);
    }
  }

  async analyzeWithAI(provider: string, target: string, type: string): Promise<any> {
    const systemPrompt = this.getAnalysisPrompt(type);
    const userPrompt = `Analyze this ${type}: ${target}`;

    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ];

    try {
      const response = await this.chat(provider, messages);
      return {
        analysis: response,
        provider,
        model: this.providers.get(provider)?.models[0],
        timestamp: new Date().toISOString()
      };
    } catch (error: any) {
      throw new Error(`Analysis failed: ${error.message}`);
    }
  }

  private getAnalysisPrompt(type: string): string {
    const prompts = {
      phone: "You are an OSINT expert specializing in phone number analysis. Provide detailed insights about the phone number including potential carrier, region, format validation, and any publicly available information. Focus on legitimate OSINT techniques only.",
      domain: "You are an OSINT expert specializing in domain and website analysis. Analyze the domain for DNS records, WHOIS information, hosting details, SSL certificates, and any publicly available information about the website.",
      social: "You are an OSINT expert specializing in social media investigation. Analyze the username or social media handle for potential accounts across platforms, naming patterns, and publicly available information.",
      email: "You are an OSINT expert specializing in email address analysis. Analyze the email for domain information, potential data breaches (public records only), and format validation.",
      general: "You are an OSINT expert. Analyze the provided target using appropriate open source intelligence techniques and provide detailed insights."
    };

    return prompts[type as keyof typeof prompts] || prompts.general;
  }

  getAvailableProviders(): Array<{name: string, status: boolean, models: string[]}> {
    const providers = [];
    
    for (const [key, provider] of Array.from(this.providers.entries())) {
      providers.push({
        name: provider.name,
        status: true,
        models: provider.models
      });
    }

    // Add offline providers
    if (!this.providers.has('grok')) {
      providers.push({ name: 'xAI Grok', status: false, models: [] });
    }
    if (!this.providers.has('deepseek')) {
      providers.push({ name: 'DeepSeek', status: false, models: [] });
    }

    return providers;
  }
}

export const aiService = new AIService();
