import { type User, type InsertUser, type AnalysisResult, type InsertAnalysisResult, type CustomTool, type InsertCustomTool, type TelegramBot, type InsertTelegramBot, type AuthorInfo, type InsertAuthorInfo } from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createAnalysisResult(result: InsertAnalysisResult): Promise<AnalysisResult>;
  getAnalysisResults(): Promise<AnalysisResult[]>;
  createCustomTool(tool: InsertCustomTool): Promise<CustomTool>;
  getCustomTools(): Promise<CustomTool[]>;
  getCustomTool(id: string): Promise<CustomTool | undefined>;
  // Telegram Bots
  createTelegramBot(bot: InsertTelegramBot): Promise<TelegramBot>;
  getTelegramBots(): Promise<TelegramBot[]>;
  getTelegramBot(id: string): Promise<TelegramBot | undefined>;
  updateTelegramBot(id: string, updates: Partial<InsertTelegramBot>): Promise<TelegramBot | undefined>;
  deleteTelegramBot(id: string): Promise<boolean>;
  // Author Info
  createOrUpdateAuthorInfo(info: InsertAuthorInfo): Promise<AuthorInfo>;
  getAuthorInfo(): Promise<AuthorInfo | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private analysisResults: Map<string, AnalysisResult>;
  private customTools: Map<string, CustomTool>;
  private telegramBots: Map<string, TelegramBot>;
  private authorInfo: AuthorInfo | undefined;

  constructor() {
    this.users = new Map();
    this.analysisResults = new Map();
    this.customTools = new Map();
    this.telegramBots = new Map();
    this.authorInfo = undefined;
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Initialize with provided Telegram bots
    const defaultBots = [
      {
        name: "Amallya Bot",
        username: "@Amallya_bot",
        description: "Мощный OSINT бот для поиска информации о людях и анализа социальных связей",
        category: "Поиск людей",
        features: ["Поиск по имени", "Анализ социальных сетей", "Связанные аккаунты"],
        isActive: true,
        rating: "4.8"
      },
      {
        name: "Find Homosapiens Bot",
        username: "@Vto43_Findhomosapiensbot",
        description: "Специализированный бот для поиска и идентификации людей через различные источники",
        category: "Поиск людей",
        features: ["Поиск по фото", "Биометрическая идентификация", "База данных"],
        isActive: true,
        rating: "4.6"
      },
      {
        name: "Glaz Bog Bot",
        username: "@Glaz_bog_Bog_GlazBot",
        description: "OSINT бот с продвинутыми возможностями анализа и мониторинга",
        category: "Анализ и мониторинг",
        features: ["Глубокий анализ", "Мониторинг изменений", "Отчеты"],
        isActive: true,
        rating: "4.7"
      },
      {
        name: "Amalya Robot",
        username: "@Amalya_robot",
        description: "Универсальный OSINT робот для комплексного анализа цифровых следов",
        category: "Универсальный",
        features: ["Комплексный анализ", "Цифровые следы", "Автоматизация"],
        isActive: true,
        rating: "4.9"
      },
      {
        name: "Pink Panther OSINT Bot",
        username: "@PinkPantherOSINTbot",
        description: "Стильный и эффективный бот для расследований и OSINT анализа",
        category: "Расследования",
        features: ["Криминалистика", "Расследования", "Анализ улик"],
        isActive: true,
        rating: "4.5"
      },
      {
        name: "Vektor Info Bot",
        username: "@vektor_info999_bot",
        description: "Информационный бот с векторным подходом к анализу данных",
        category: "Информационный анализ",
        features: ["Векторный анализ", "Big Data", "Аналитика"],
        isActive: true,
        rating: "4.4"
      },
      {
        name: "Angel OSINT Robot",
        username: "@AngelOSINTRobot",
        description: "Бот-ангел для этичного OSINT и защиты конфиденциальности",
        category: "Этичный OSINT",
        features: ["Этичный подход", "Защита данных", "Безопасность"],
        isActive: true,
        rating: "4.8"
      },
      {
        name: "VK History Robot",
        username: "@VKHistoryRobot",
        description: "Специализированный бот для анализа истории и активности ВКонтакте",
        category: "Социальные сети",
        features: ["История ВК", "Анализ активности", "Архивные данные"],
        isActive: true,
        rating: "4.6"
      },
      {
        name: "Loggers Psyhopatiya Bot",
        username: "@Loggers_psyhopatiyaa_bot",
        description: "Продвинутый бот для логирования и анализа поведенческих паттернов",
        category: "Поведенческий анализ",
        features: ["Логирование", "Поведенческий анализ", "Паттерны"],
        isActive: true,
        rating: "4.3"
      },
      {
        name: "TT OSINT Bot",
        username: "@TTOSINT_bot",
        description: "Быстрый и эффективный OSINT бот для оперативного анализа",
        category: "Оперативный анализ",
        features: ["Быстрый анализ", "Оперативность", "Эффективность"],
        isActive: true,
        rating: "4.7"
      },
      {
        name: "Fun Statast Bot",
        username: "@funstatast2_bot",
        description: "Развлекательный бот со статистическим анализом и интересными фактами",
        category: "Статистика",
        features: ["Статистика", "Развлечения", "Факты"],
        isActive: true,
        rating: "4.2"
      },
      {
        name: "Social Graph OSINT Bot",
        username: "@social_graph_osint_bot",
        description: "Бот для анализа социальных графов и связей между людьми",
        category: "Социальный граф",
        features: ["Социальные связи", "Граф анализ", "Сетевой анализ"],
        isActive: true,
        rating: "4.9"
      },
      {
        name: "Egrul Bot",
        username: "@egrul_bot",
        description: "Бот для работы с ЕГРЮЛ и анализа юридических лиц",
        category: "Юридический анализ",
        features: ["ЕГРЮЛ", "Юридические лица", "Корпоративный анализ"],
        isActive: true,
        rating: "4.8"
      }
    ];

    defaultBots.forEach((bot, index) => {
      const id = randomUUID();
      const telegramBot: TelegramBot = {
        id,
        name: bot.name,
        username: bot.username,
        description: bot.description,
        category: bot.category,
        features: bot.features,
        isActive: bot.isActive,
        rating: bot.rating,
        addedAt: new Date()
      };
      this.telegramBots.set(id, telegramBot);
    });

    // Initialize authors info (multiple authors)
    this.authorInfo = {
      id: randomUUID(),
      name: "Команда разработчиков Sora",
      title: "OSINT Specialists & Development Team",
      bio: "Команда профессиональных специалистов по OSINT (Open Source Intelligence) и разработке. Создатели платформы 'Sora' (ранее 'Крис') - мощного инструмента для легального сбора разведывательной информации из открытых источников с интеграцией ИИ.",
      skills: [
        "OSINT (Open Source Intelligence)",
        "Доксинг и эдиторство", 
        "Программирование и разработка",
        "UI/UX дизайн",
        "Кибербезопасность",
        "Анализ данных",
        "Python/JavaScript разработка",
        "Веб-скрейпинг",
        "Социальная инженерия",
        "Сетевой анализ",
        "Машинное обучение",
        "Криминалистика"
      ],
      achievements: [
        "🏆 Создание платформы OSINT 'Sora' с ИИ поддержкой (Grok + DeepSeek)",
        "👥 Активное комьюнити доксинга и OSINT исследований", 
        "🔍 Тысячи успешных OSINT расследований",
        "🎨 Красивый и удобный интерфейс с анимациями",
        "🤖 Интеграция передовых ИИ моделей для анализа",
        "📱 Коллекция специализированных Telegram ботов",
        "🌐 Встроенные OSINT framework и инструменты",
        "💻 Интегрированный терминал и файловый менеджер",
        "🎵 Встроенные музыкальные сервисы для комфорта",
        "📈 Разработка уникальных алгоритмов поиска"
      ],
      socialLinks: {
        amalya_telegram: "@cluim",
        amalya_adapter: "https://t.me/adapetamaly", 
        amalya_channel: "https://t.me/attackamalya",
        shepot_telegram: "@oxaul",
        shepot_adapter: "https://t.me/adp_oxaul",
        shepot_channel: "https://t.me/+xx4qh91uyS0xN2U0"
      },
      avatar: null,
      updatedAt: new Date()
    };
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createAnalysisResult(insertResult: InsertAnalysisResult): Promise<AnalysisResult> {
    const id = randomUUID();
    const result: AnalysisResult = {
      ...insertResult,
      id,
      timestamp: new Date(),
      results: insertResult.results || {},
      status: insertResult.status || 'pending'
    };
    this.analysisResults.set(id, result);
    return result;
  }

  async getAnalysisResults(): Promise<AnalysisResult[]> {
    return Array.from(this.analysisResults.values()).sort(
      (a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0)
    );
  }

  async createCustomTool(insertTool: InsertCustomTool): Promise<CustomTool> {
    const id = randomUUID();
    const tool: CustomTool = {
      ...insertTool,
      id,
      isActive: true,
      uploadedAt: new Date(),
      description: insertTool.description || null
    };
    this.customTools.set(id, tool);
    return tool;
  }

  async getCustomTools(): Promise<CustomTool[]> {
    return Array.from(this.customTools.values()).sort(
      (a, b) => (b.uploadedAt?.getTime() || 0) - (a.uploadedAt?.getTime() || 0)
    );
  }

  async getCustomTool(id: string): Promise<CustomTool | undefined> {
    return this.customTools.get(id);
  }

  // Telegram Bots methods
  async createTelegramBot(insertBot: InsertTelegramBot): Promise<TelegramBot> {
    const id = randomUUID();
    const bot: TelegramBot = {
      ...insertBot,
      id,
      addedAt: new Date(),
      isActive: insertBot.isActive ?? true,
      rating: insertBot.rating ?? "0.0"
    };
    this.telegramBots.set(id, bot);
    return bot;
  }

  async getTelegramBots(): Promise<TelegramBot[]> {
    return Array.from(this.telegramBots.values()).sort(
      (a, b) => (b.addedAt?.getTime() || 0) - (a.addedAt?.getTime() || 0)
    );
  }

  async getTelegramBot(id: string): Promise<TelegramBot | undefined> {
    return this.telegramBots.get(id);
  }

  async updateTelegramBot(id: string, updates: Partial<InsertTelegramBot>): Promise<TelegramBot | undefined> {
    const bot = this.telegramBots.get(id);
    if (!bot) return undefined;
    
    const updatedBot: TelegramBot = { ...bot, ...updates };
    this.telegramBots.set(id, updatedBot);
    return updatedBot;
  }

  async deleteTelegramBot(id: string): Promise<boolean> {
    return this.telegramBots.delete(id);
  }

  // Author Info methods
  async createOrUpdateAuthorInfo(insertInfo: InsertAuthorInfo): Promise<AuthorInfo> {
    const info: AuthorInfo = {
      ...insertInfo,
      id: this.authorInfo?.id || randomUUID(),
      updatedAt: new Date()
    };
    this.authorInfo = info;
    return info;
  }

  async getAuthorInfo(): Promise<AuthorInfo | undefined> {
    return this.authorInfo;
  }
}

export const storage = new MemStorage();
