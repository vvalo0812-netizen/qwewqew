const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 Начинаю сборку Sora OSINT Platform...');

// Проверяем существование папки проекта
const projectRoot = path.join(__dirname, '..');
if (!fs.existsSync(projectRoot)) {
  console.error('❌ Не найден корень проекта');
  process.exit(1);
}

console.log('📦 Установка зависимостей Electron...');
try {
  execSync('npm install', { 
    cwd: __dirname,
    stdio: 'inherit'
  });
} catch (error) {
  console.error('❌ Ошибка установки зависимостей:', error.message);
  process.exit(1);
}

console.log('🏗️ Сборка frontend приложения...');
try {
  execSync('npm run build', { 
    cwd: projectRoot,
    stdio: 'inherit'
  });
} catch (error) {
  console.error('❌ Ошибка сборки frontend:', error.message);
  process.exit(1);
}

console.log('📁 Копирование файлов...');
const distPath = path.join(projectRoot, 'dist');
const exeDistPath = path.join(__dirname, 'dist');

// Копируем собранное приложение
if (fs.existsSync(distPath)) {
  if (fs.existsSync(exeDistPath)) {
    fs.rmSync(exeDistPath, { recursive: true, force: true });
  }
  fs.cpSync(distPath, exeDistPath, { recursive: true });
  console.log('✅ Frontend файлы скопированы');
} else {
  console.error('❌ Не найдена папка dist для frontend');
  process.exit(1);
}

// Копируем серверные файлы
const serverFiles = ['server', 'shared'];
serverFiles.forEach(dir => {
  const srcPath = path.join(projectRoot, dir);
  const destPath = path.join(__dirname, dir);
  
  if (fs.existsSync(srcPath)) {
    if (fs.existsSync(destPath)) {
      fs.rmSync(destPath, { recursive: true, force: true });
    }
    fs.cpSync(srcPath, destPath, { recursive: true });
    console.log(`✅ ${dir} файлы скопированы`);
  }
});

// Копируем package.json и другие необходимые файлы
const rootPackageJson = path.join(projectRoot, 'package.json');
const serverPackageJson = path.join(__dirname, 'server-package.json');
if (fs.existsSync(rootPackageJson)) {
  fs.copyFileSync(rootPackageJson, serverPackageJson);
  console.log('✅ package.json скопирован');
}

console.log('⚡ Сборка .exe файла...');
try {
  execSync('npm run build', { 
    cwd: __dirname,
    stdio: 'inherit'
  });
  console.log('🎉 ✨ Sora OSINT Platform успешно собран! ✨');
  console.log('📍 Найти .exe файл в: exe/dist/');
} catch (error) {
  console.error('❌ Ошибка сборки .exe:', error.message);
  process.exit(1);
}