const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 5000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'dist', 'public')));

// Simple in-memory storage for demo
let storage = {
  providers: [
    { name: 'Grok', status: true, models: ['grok-beta'] },
    { name: 'DeepSeek', status: true, models: ['deepseek-chat'] }
  ],
  telegramBots: [],
  users: new Map(),
  authorInfo: {
    name: "Команда разработчиков Sora",
    title: "OSINT Specialists & Development Team",
    bio: "Команда профессиональных специалистов по OSINT и разработке. Создатели платформы 'Sora' - мощного инструмента для легального сбора разведывательной информации из открытых источников.",
    skills: [
      "OSINT (Open Source Intelligence)",
      "Доксинг и эдиторство", 
      "Программирование и разработка",
      "UI/UX дизайн",
      "Кибербезопасность"
    ],
    achievements: [
      "🏆 Создание платформы OSINT 'Sora' с ИИ поддержкой",
      "👥 Активное комьюнити доксинга и OSINT исследований",
      "🔍 Тысячи успешных OSINT расследований",
      "🎨 Красивый и удобный интерфейс с анимациями"
    ],
    socialLinks: {
      amalya_telegram: "@cluim",
      amalya_adapter: "https://t.me/adapetamaly", 
      shepot_telegram: "@oxaul",
      shepot_adapter: "https://t.me/adp_oxaul"
    }
  }
};

// API Routes
app.get('/api/ai/providers', (req, res) => {
  res.json(storage.providers);
});

app.get('/api/author', (req, res) => {
  res.json(storage.authorInfo);
});

app.get('/api/telegram-bots', (req, res) => {
  // Return hardcoded bots for demo
  const bots = [
    {
      id: 'eyeofbeholder',
      name: 'Eye of Beholder',
      username: '@eyeofbeholder_bot',
      description: 'Поиск информации по номеру телефона',
      category: 'phone',
      features: ['Поиск по номеру', 'История звонков', 'Геолокация']
    },
    {
      id: 'getcontact',
      name: 'GetContact Info',
      username: '@getcontact_real_bot',
      description: 'Определение имени по номеру телефона',
      category: 'phone',
      features: ['Имя абонента', 'Фото профиля', 'Социальные сети']
    }
  ];
  res.json(bots);
});

// Catch all handler for SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'public', 'index.html'));
});

// Start server
app.listen(PORT, '127.0.0.1', () => {
  console.log(`Sora OSINT Platform server running on http://127.0.0.1:${PORT}`);
});

module.exports = app;