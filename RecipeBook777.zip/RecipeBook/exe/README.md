# Sora OSINT Platform - Portable Edition

![Sora OSINT](icon.png)

## 🚀 Quick Start

1. **Windows**: Double-click `sora-launcher.bat`
2. **Cross-platform**: Run `node server.js`
3. Open browser: `http://127.0.0.1:5000`
4. **Password**: `Amalya`

## 📋 Requirements

- Node.js 16+ (Download from https://nodejs.org/)
- Windows 10/11 or compatible OS

## 🔧 Manual Setup

```bash
npm install
node server.js
```

## 🎯 Features

- **OSINT Tools**: Phone analysis, domain research, social media investigation
- **AI Integration**: Grok and DeepSeek AI models
- **Terminal Interface**: Built-in command line
- **File Management**: Upload and manage investigation files
- **Professional UI**: Cyberpunk design with smooth animations

## 🔑 Default Credentials

- **Password**: `Amalya`
- **Port**: `5000`

## 👥 Development Team

- **Amalya** - @cluim (Telegram: @adapetamaly)
- **Шёпот** - @oxaul (Telegram: @adp_oxaul)

## 📖 License

MIT License - Professional OSINT Platform