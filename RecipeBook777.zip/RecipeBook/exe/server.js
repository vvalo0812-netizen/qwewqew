const express = require('express');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const PORT = 5000;

console.log('🚀 Sora OSINT Platform v1.0.0');
console.log('👨‍💻 Created by Amalya & Shepot');
console.log('🔑 Password: Amalya');
console.log('🌐 Server starting on http://127.0.0.1:5000...');
console.log('');

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'dist', 'public')));

// Terminal sessions for standalone version
const terminalSessions = new Map();

// WebSocket handling for terminal
wss.on('connection', (ws) => {
  const sessionId = Date.now().toString();
  console.log(`💻 Terminal session ${sessionId} connected`);
  
  // Create bash session for Windows (using cmd as fallback)
  const isWindows = process.platform === 'win32';
  const shell = isWindows ? 'cmd' : 'bash';
  const shellArgs = isWindows ? ['/k'] : [];
  
  try {
    const terminal = spawn(shell, shellArgs, {
      cwd: __dirname,
      env: { ...process.env, TERM: 'xterm-256color' }
    });
    
    terminalSessions.set(sessionId, terminal);
    
    // Send initial prompt
    ws.send(JSON.stringify({
      type: 'output',
      data: `Крис@sora-platform:${__dirname}$ `
    }));
    
    // Handle terminal output
    terminal.stdout.on('data', (data) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'output',
          data: data.toString()
        }));
      }
    });
    
    terminal.stderr.on('data', (data) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'output',
          data: data.toString()
        }));
      }
    });
    
    // Handle WebSocket messages (commands)
    ws.on('message', (message) => {
      try {
        const { type, data } = JSON.parse(message);
        if (type === 'command') {
          // Handle built-in commands
          if (data.trim().toLowerCase() === 'cls' || data.trim().toLowerCase() === 'clear') {
            ws.send(JSON.stringify({
              type: 'output',
              data: '\x1b[2J\x1b[0f' // ANSI clear screen
            }));
            ws.send(JSON.stringify({
              type: 'output',
              data: `Крис@sora-platform:${__dirname}$ `
            }));
          } else {
            terminal.stdin.write(data + (isWindows ? '\r\n' : '\n'));
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    // Cleanup on disconnect
    ws.on('close', () => {
      console.log(`💻 Terminal session ${sessionId} disconnected`);
      terminal.kill();
      terminalSessions.delete(sessionId);
    });
    
  } catch (error) {
    console.error('Failed to create terminal session:', error);
    ws.send(JSON.stringify({
      type: 'output',
      data: 'Error: Failed to create terminal session\n'
    }));
  }
});

// Simple in-memory storage for demo
let storage = {
  providers: [
    { name: 'xAI Grok', status: true, models: ['grok-2-1212', 'grok-beta'] },
    { name: 'DeepSeek', status: true, models: ['deepseek-chat', 'deepseek-coder'] },
    { name: 'OpenAI GPT', status: true, models: ['gpt-5', 'gpt-4o'] }
  ],
  telegramBots: [],
  users: new Map(),
  authorInfo: {
    name: "Команда разработчиков Sora",
    title: "OSINT Specialists & Development Team",
    bio: "Команда профессиональных специалистов по OSINT и разработке. Создатели платформы 'Sora' - мощного инструмента для легального сбора разведывательной информации из открытых источников.",
    skills: [
      "OSINT (Open Source Intelligence)",
      "Доксинг и эдиторство", 
      "Программирование и разработка",
      "UI/UX дизайн",
      "Кибербезопасность"
    ],
    achievements: [
      "🏆 Создание платформы OSINT 'Sora' с ИИ поддержкой",
      "👥 Активное комьюнити доксинга и OSINT исследований",
      "🔍 Тысячи успешных OSINT расследований",
      "🎨 Красивый и удобный интерфейс с анимациями"
    ],
    socialLinks: {
      amalya_telegram: "@cluim",
      amalya_adapter: "https://t.me/adapetamaly", 
      shepot_telegram: "@oxaul",
      shepot_adapter: "https://t.me/adp_oxaul"
    }
  }
};

// AI Chat API with demo responses
app.post('/api/ai/chat', (req, res) => {
  const { provider, messages } = req.body;
  
  // Simulate AI response with enhanced demo mode
  const lastMessage = messages[messages.length - 1]?.content || '';
  const isOSINTQuery = /\b(phone|domain|email|social|username|ip|whois|dns|osint|investigate|analysis|dork|google)\b/i.test(lastMessage);
  
  const demoResponses = {
    'xai grok': isOSINTQuery ? [
      `🕵️ **Grok OSINT Analysis (Demo Mode)**\n\n📱 **Target:** ${lastMessage.substring(0, 100)}${lastMessage.length > 100 ? '...' : ''}\n\n🔍 **OSINT Recommendations:**\n• Use Google Dorks: site:example.com "target"\n• Check social media platforms\n• Verify through WHOIS databases\n• Cross-reference with breach databases\n\n⚠️ **Note:** This is demo mode. Add XAI_API_KEY for real-time analysis.`,
      `🎯 **Grok Tactical Analysis (Demo)**\n\n📋 **Investigation Strategy:**\n1. 🔎 Primary reconnaissance\n2. 🌐 Social media enumeration\n3. 📊 Public records analysis\n4. 🔐 Security assessment\n\n💡 **Suggested Google Dorks:**\n• "${lastMessage.split(' ')[0]}" filetype:pdf\n• site:linkedin.com "${lastMessage.split(' ')[0]}"\n\n🔑 **Full Analysis:** Requires XAI_API_KEY`
    ] : [
      `🤖 **Grok Demo Response**\n\nВаш запрос: "${lastMessage.substring(0, 50)}..."\n\nЭто демонстрационный режим. Для полной функциональности добавьте XAI_API_KEY в настройки.`,
      `⚡ **Grok Processing**\n\n${lastMessage}\n\nВ реальном режиме предоставляю детальный анализ с OSINT рекомендациями.`
    ],
    deepseek: isOSINTQuery ? [
      `🧠 **DeepSeek OSINT Framework (Demo)**\n\n🎯 **Target Analysis:** ${lastMessage.substring(0, 100)}\n\n🔧 **Technical Assessment:**\n• DNS enumeration patterns\n• Subdomain discovery methods\n• Certificate transparency logs\n\n💻 **Code-Based Tools:**\n\`\`\`bash\nnslookup target.com\nwhois target.com\n\`\`\`\n\n🔑 **Full Framework:** Add DEEPSEEK_API_KEY`,
      `🔍 **DeepSeek Technical Intel (Demo)**\n\n📊 **Analysis Framework:**\n1. 🛡️ Security posture assessment\n2. 🌐 Infrastructure mapping\n3. 🐍 Python OSINT tools\n\n💡 Enable with DEEPSEEK_API_KEY`
    ] : [
      `🧠 **DeepSeek Demo**\n\nАнализирую: "${lastMessage.substring(0, 50)}..."\n\nСпециализируюсь на техническом анализе и создании OSINT инструментов.`,
      `💡 **DeepSeek Response**\n\n${lastMessage}\n\nВ полной версии предоставляю детальный код-анализ с DEEPSEEK_API_KEY.`
    ],
    'openai gpt': isOSINTQuery ? [
      `🌟 **GPT-5 OSINT Assistant (Demo)**\n\n🔍 **Investigation Target:** ${lastMessage.substring(0, 100)}\n\n📋 **Comprehensive Analysis Plan:**\n• Multi-source data correlation\n• Pattern recognition analysis\n• Cross-platform verification\n\n🎯 **Advanced Google Dorks:**\n• "${lastMessage.split(' ')[0]}" (site:pastebin.com OR site:github.com)\n• filetype:pdf "${lastMessage.split(' ')[0]}"\n\n🔑 **Full GPT-5 Analysis:** Requires OPENAI_API_KEY`,
      `🚀 **GPT-5 Professional OSINT (Demo)**\n\n🎭 **Target Profile Development:**\n1. Digital footprint mapping\n2. Relationship network analysis\n3. Geolocation correlation\n\n🛠️ **Recommended Tools Integration:**\n• Maltego for link analysis\n• Shodan for infrastructure scan\n\n💎 Unlock GPT-5's full potential with OPENAI_API_KEY`
    ] : [
      `🌟 **GPT-5 Demo Mode**\n\nЗапрос: "${lastMessage.substring(0, 50)}..."\n\n• GPT-5 - самая современная модель (выпущена 7 августа 2025)\n• Мультимодальная обработка\n• Специализированная OSINT поддержка\n\nДля активации добавьте OPENAI_API_KEY.`,
      `💫 **GPT-5 Advanced Response**\n\n${lastMessage}\n\nВ полном режиме предоставляю:\n• Контекстуальный анализ на 131k токенов\n• Обработка изображений\n• Персонализированные рекомендации\n\nАктивируйте с OPENAI_API_KEY`
    ]
  };
  
  const responses = demoResponses[provider.toLowerCase()] || demoResponses['xai grok'];
  const response = responses[Math.floor(Math.random() * responses.length)];
  
  // Simulate API delay
  setTimeout(() => {
    res.json({ response });
  }, 1000 + Math.random() * 2000);
});

// OSINT Analysis API
app.post('/api/osint/analyze', (req, res) => {
  const { target, type } = req.body;
  
  // Simulate OSINT analysis
  const analysis = {
    target,
    type,
    results: {
      analysis: {
        analysis: `🔍 **OSINT Analysis Results for ${target}**\n\n🎯 **Target Type:** ${type}\n📅 **Analysis Date:** ${new Date().toLocaleString()}\n\n📊 **Findings:**\n• Basic information gathered\n• Public records checked\n• Social media presence verified\n\n⚠️ **Demo Mode:** This is a demonstration. Real analysis requires proper API configuration.`,
        provider: 'demo',
        timestamp: new Date().toISOString()
      },
      formatted: target,
      isValid: true
    },
    timestamp: new Date().toISOString(),
    status: 'success'
  };
  
  setTimeout(() => {
    res.json(analysis);
  }, 2000 + Math.random() * 3000);
});

// API Routes
app.get('/api/ai/providers', (req, res) => {
  res.json(storage.providers);
});

app.get('/api/author', (req, res) => {
  res.json(storage.authorInfo);
});

app.get('/api/telegram-bots', (req, res) => {
  // Return hardcoded bots for demo
  const bots = [
    {
      id: 'eyeofbeholder',
      name: 'Eye of Beholder',
      username: '@eyeofbeholder_bot',
      description: 'Поиск информации по номеру телефона',
      category: 'phone',
      features: ['Поиск по номеру', 'История звонков', 'Геолокация']
    },
    {
      id: 'getcontact',
      name: 'GetContact Info',
      username: '@getcontact_real_bot',
      description: 'Определение имени по номеру телефона',
      category: 'phone',
      features: ['Имя абонента', 'Фото профиля', 'Социальные сети']
    }
  ];
  res.json(bots);
});

// Catch all handler for SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'public', 'index.html'));
});

// Auto-open browser with better error handling
setTimeout(() => {
  const url = 'http://127.0.0.1:5000';
  console.log(`🌐 Opening Sora OSINT Platform: ${url}`);
  console.log('🔑 Password: Amalya');
  console.log('👨‍💻 Created by Amalya & Shepot');
  console.log('');
  
  // Try to open browser if available
  try {
    const { exec } = require('child_process');
    const command = process.platform === 'win32' ? 'start' : 
                   process.platform === 'darwin' ? 'open' : 'xdg-open';
    exec(`${command} ${url}`);
  } catch (error) {
    console.log('⚠️  Could not auto-open browser. Please navigate to:', url);
  }
}, 3000);

// Start server
server.listen(PORT, '127.0.0.1', () => {
  console.log(`✅ Sora OSINT Platform server running on http://127.0.0.1:${PORT}`);
  console.log('🖐️  Press Ctrl+C to stop server');
  console.log('');
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🚀 Sora OSINT Platform shutting down...');
  server.close(() => {
    console.log('✅ Server stopped successfully');
    process.exit(0);
  });
});

module.exports = app;